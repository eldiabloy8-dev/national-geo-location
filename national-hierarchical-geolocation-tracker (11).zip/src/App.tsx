import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { 
  MapPin, Upload, Database, RefreshCw, Trash2,
  BarChart3, Map as MapIcon, Search, ChevronDown, ChevronRight,
  Building2, Users, Store, AlertTriangle,
  XCircle, FileSpreadsheet, Eye, TrendingUp,
  Plus, Edit2, Save, X, Globe, Layers, Shield, LogOut
} from 'lucide-react';
import { LoginPage, SecurityPanel, getCurrentSession, logout, type LoggedInUser } from './Auth';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import { Icon, LatLngBounds, divIcon, point } from 'leaflet';
import MarkerClusterGroup from 'react-leaflet-cluster';
import 'leaflet.markercluster/dist/MarkerCluster.css';
import 'leaflet.markercluster/dist/MarkerCluster.Default.css';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell, AreaChart, Area
} from 'recharts';
import { format, parseISO, eachDayOfInterval } from 'date-fns';
import * as XLSX from 'xlsx';
import 'leaflet/dist/leaflet.css';

// Types
interface HierarchyNode {
  id: string;
  name: string;
  type: 'national' | 'region' | 'area' | 'territory' | 'salesPoint';
  parentId: string | null;
  salesPointCode?: string;
}

interface VisitRecord {
  id: string;
  salesPointId: string;
  salesPointName: string;
  salesPointCode: string;
  territoryId: string;
  territoryName: string;
  areaId: string;
  areaName: string;
  regionId: string;
  regionName: string;
  nationalId: string;
  visitDate: string;
  routeName: string;
  outletCode: string;
  outletName: string;
  distance: number;
  lat: number;
  long: number;
}

interface KPIData {
  totalVisits: number;
  uniqueOutlets: number;
  violations: number;
  duplicates: number;
  violationRate: number;
  duplicateRate: number;
}

interface AggregatedData {
  key: string;
  name: string;
  totalVisits: number;
  uniqueOutlets: number;
  violations: number;
  duplicates: number;
  type: string;
}

// Fix Leaflet default icon issue
const defaultIcon = new Icon({
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const violationIcon = new Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

// Initial hierarchy data
const initialHierarchy: HierarchyNode[] = [
  { id: 'national-1', name: 'Bangladesh', type: 'national', parentId: null },
  
  // Regions
  { id: 'region-1', name: 'Dhaka Region', type: 'region', parentId: 'national-1' },
  { id: 'region-2', name: 'Chittagong Region', type: 'region', parentId: 'national-1' },
  { id: 'region-3', name: 'Rajshahi Region', type: 'region', parentId: 'national-1' },
  { id: 'region-4', name: 'Khulna Region', type: 'region', parentId: 'national-1' },
  
  // Areas under Dhaka
  { id: 'area-1', name: 'Dhaka North', type: 'area', parentId: 'region-1' },
  { id: 'area-2', name: 'Dhaka South', type: 'area', parentId: 'region-1' },
  { id: 'area-3', name: 'Gazipur', type: 'area', parentId: 'region-1' },
  
  // Areas under Chittagong
  { id: 'area-4', name: 'Chittagong City', type: 'area', parentId: 'region-2' },
  { id: 'area-5', name: 'Cox\'s Bazar', type: 'area', parentId: 'region-2' },
  { id: 'area-6', name: 'Noakhali', type: 'area', parentId: 'region-2' },
  
  // Areas under Rajshahi
  { id: 'area-7', name: 'Rajshahi City', type: 'area', parentId: 'region-3' },
  { id: 'area-8', name: 'Bogra', type: 'area', parentId: 'region-3' },
  
  // Areas under Khulna
  { id: 'area-9', name: 'Khulna City', type: 'area', parentId: 'region-4' },
  { id: 'area-10', name: 'Jessore', type: 'area', parentId: 'region-4' },
  
  // Territories and Sales Points
  { id: 'ter-1', name: 'Uttara', type: 'territory', parentId: 'area-1' },
  { id: 'sp-1', name: 'Uttara SP-1', type: 'salesPoint', parentId: 'ter-1' },
  { id: 'sp-2', name: 'Uttara SP-2', type: 'salesPoint', parentId: 'ter-1' },
  
  { id: 'ter-2', name: 'Gulshan', type: 'territory', parentId: 'area-1' },
  { id: 'sp-3', name: 'Gulshan SP-1', type: 'salesPoint', parentId: 'ter-2' },
  
  { id: 'ter-3', name: 'Mirpur', type: 'territory', parentId: 'area-1' },
  { id: 'sp-4', name: 'Mirpur SP-1', type: 'salesPoint', parentId: 'ter-3' },
  { id: 'sp-5', name: 'Mirpur SP-2', type: 'salesPoint', parentId: 'ter-3' },
  
  { id: 'ter-4', name: 'Dhanmondi', type: 'territory', parentId: 'area-2' },
  { id: 'sp-6', name: 'Dhanmondi SP-1', type: 'salesPoint', parentId: 'ter-4' },
  
  { id: 'ter-5', name: 'Motijheel', type: 'territory', parentId: 'area-2' },
  { id: 'sp-7', name: 'Motijheel SP-1', type: 'salesPoint', parentId: 'ter-5' },
  { id: 'sp-8', name: 'Motijheel SP-2', type: 'salesPoint', parentId: 'ter-5' },
  
  { id: 'ter-6', name: 'Gazipur Sadar', type: 'territory', parentId: 'area-3' },
  { id: 'sp-9', name: 'Gazipur SP-1', type: 'salesPoint', parentId: 'ter-6' },
  
  { id: 'ter-7', name: 'Tongi', type: 'territory', parentId: 'area-3' },
  { id: 'sp-10', name: 'Tongi SP-1', type: 'salesPoint', parentId: 'ter-7' },
  
  { id: 'ter-8', name: 'Agrabad', type: 'territory', parentId: 'area-4' },
  { id: 'sp-11', name: 'Agrabad SP-1', type: 'salesPoint', parentId: 'ter-8' },
  { id: 'sp-12', name: 'Agrabad SP-2', type: 'salesPoint', parentId: 'ter-8' },
  
  { id: 'ter-9', name: 'Halishahar', type: 'territory', parentId: 'area-4' },
  { id: 'sp-13', name: 'Halishahar SP-1', type: 'salesPoint', parentId: 'ter-9' },
  
  { id: 'ter-10', name: 'Cox\'s Bazar Sadar', type: 'territory', parentId: 'area-5' },
  { id: 'sp-14', name: 'Cox SP-1', type: 'salesPoint', parentId: 'ter-10' },
  
  { id: 'ter-11', name: 'Teknaf', type: 'territory', parentId: 'area-5' },
  { id: 'sp-15', name: 'Teknaf SP-1', type: 'salesPoint', parentId: 'ter-11' },
  
  { id: 'ter-12', name: 'Maijdee', type: 'territory', parentId: 'area-6' },
  { id: 'sp-16', name: 'Maijdee', type: 'salesPoint', parentId: 'ter-12' },
  { id: 'sp-17', name: 'Udarhat', type: 'salesPoint', parentId: 'ter-12' },
  
  { id: 'ter-13', name: 'Noakhali Sadar', type: 'territory', parentId: 'area-6' },
  { id: 'sp-18', name: 'Noakhali SP-1', type: 'salesPoint', parentId: 'ter-13' },
  
  { id: 'ter-14', name: 'Rajshahi Sadar', type: 'territory', parentId: 'area-7' },
  { id: 'sp-19', name: 'Rajshahi SP-1', type: 'salesPoint', parentId: 'ter-14' },
  
  { id: 'ter-15', name: 'Bogra Sadar', type: 'territory', parentId: 'area-8' },
  { id: 'sp-20', name: 'Bogra SP-1', type: 'salesPoint', parentId: 'ter-15' },
  
  { id: 'ter-16', name: 'Khulna Sadar', type: 'territory', parentId: 'area-9' },
  { id: 'sp-21', name: 'Khulna SP-1', type: 'salesPoint', parentId: 'ter-16' },
  
  { id: 'ter-17', name: 'Jessore Sadar', type: 'territory', parentId: 'area-10' },
  { id: 'sp-22', name: 'Jessore SP-1', type: 'salesPoint', parentId: 'ter-17' },
  { id: 'sp-23', name: 'Jessore SP-2', type: 'salesPoint', parentId: 'ter-17' },
];

const salesPointCodeMap: Record<string, string> = {
  'sp-1': 'DHA-UTT-01',
  'sp-2': 'DHA-UTT-02',
  'sp-3': 'DHA-GUL-01',
  'sp-4': 'DHA-MIR-01',
  'sp-5': 'DHA-MIR-02',
  'sp-6': 'DHA-DMN-01',
  'sp-7': 'DHA-MOT-01',
  'sp-8': 'DHA-MOT-02',
  'sp-9': 'DHA-GAZ-01',
  'sp-10': 'DHA-TON-01',
  'sp-11': 'CTG-AGR-01',
  'sp-12': 'CTG-AGR-02',
  'sp-13': 'CTG-HAL-01',
  'sp-14': 'CTG-CXB-01',
  'sp-15': 'CTG-TEK-01',
  'sp-16': 'NOA-MAJ-01',
  'sp-17': 'NOA-UDH-01',
  'sp-18': 'NOA-NKL-01',
  'sp-19': 'RAJ-RAJ-01',
  'sp-20': 'RAJ-BOG-01',
  'sp-21': 'KHU-KHU-01',
  'sp-22': 'KHU-JES-01',
  'sp-23': 'KHU-JES-02',
};

initialHierarchy.forEach((node) => {
  if (node.type === 'salesPoint') {
    node.salesPointCode = salesPointCodeMap[node.id] || node.id.toUpperCase();
  }
});

// Generate sample data
const generateSampleData = (): VisitRecord[] => {
  const data: VisitRecord[] = [];
  const salesPoints = initialHierarchy.filter(n => n.type === 'salesPoint');
  const routes = ['Route A', 'Route B', 'Route C', 'Route D', 'Route E'];
  const outlets = ['Outlet 001', 'Outlet 002', 'Outlet 003', 'Outlet 004', 'Outlet 005', 'Outlet 006', 'Outlet 007', 'Outlet 008'];
  
  const today = new Date();
  
  salesPoints.forEach((sp, spIndex) => {
    const territory = initialHierarchy.find(n => n.id === sp.parentId)!;
    const area = initialHierarchy.find(n => n.id === territory.parentId)!;
    const region = initialHierarchy.find(n => n.id === area.parentId)!;
    const national = initialHierarchy.find(n => n.id === region.parentId)!;
    
    // Generate visits for last 30 days
    for (let i = 0; i < 30; i++) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      const dateStr = format(date, 'yyyy-MM-dd');
      
      // 3-8 visits per day per sales point
      const visitsPerDay = Math.floor(Math.random() * 6) + 3;
      
      for (let v = 0; v < visitsPerDay; v++) {
        const route = routes[Math.floor(Math.random() * routes.length)];
        const outlet = outlets[Math.floor(Math.random() * outlets.length)];
        const distance = Math.random() * 100;
        
        // Random coordinates around Bangladesh
        const baseLat = 23.8103 + (Math.random() - 0.5) * 4;
        const baseLong = 90.4125 + (Math.random() - 0.5) * 4;
        
        data.push({
          id: `visit-${spIndex}-${i}-${v}`,
          salesPointId: sp.id,
          salesPointName: sp.name,
          salesPointCode: sp.salesPointCode || salesPointCodeMap[sp.id] || sp.id.toUpperCase(),
          territoryId: territory.id,
          territoryName: territory.name,
          areaId: area.id,
          areaName: area.name,
          regionId: region.id,
          regionName: region.name,
          nationalId: national.id,
          visitDate: dateStr,
          routeName: route,
          outletCode: `${sp.id}-${outlet.split(' ')[1]}`,
          outletName: `${sp.name} - ${outlet}`,
          distance: Math.round(distance * 10) / 10,
          lat: baseLat,
          long: baseLong
        });
      }
    }
  });
  
  return data;
};

// Reusable Multi-Select Dropdown Component
interface MultiSelectProps {
  options: { id: string; label: string; sublabel?: string; count?: number }[];
  selected: string[];
  onChange: (selected: string[]) => void;
  placeholder?: string;
  maxHeight?: string;
}

function MultiSelect({ options, selected, onChange, placeholder = 'Select...', maxHeight = '240px' }: MultiSelectProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState('');
  const containerRef = React.useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const filtered = options.filter(o =>
    o.label.toLowerCase().includes(search.toLowerCase()) ||
    (o.sublabel && o.sublabel.toLowerCase().includes(search.toLowerCase()))
  );

  const allSelected = filtered.length > 0 && filtered.every(o => selected.includes(o.id));

  const toggle = (id: string) => {
    if (selected.includes(id)) {
      onChange(selected.filter(s => s !== id));
    } else {
      onChange([...selected, id]);
    }
  };

  const toggleAll = () => {
    if (allSelected) {
      onChange(selected.filter(s => !filtered.some(o => o.id === s)));
    } else {
      const newIds = filtered.map(o => o.id).filter(id => !selected.includes(id));
      onChange([...selected, ...newIds]);
    }
  };

  const clearAll = () => {
    onChange([]);
  };

  return (
    <div ref={containerRef} className="relative">
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-left focus:outline-none focus:ring-2 focus:ring-indigo-500 hover:border-indigo-400 transition-colors"
      >
        <span className="truncate text-slate-700">
          {selected.length === 0
            ? <span className="text-slate-400">{placeholder}</span>
            : selected.length === options.length
            ? `All ${options.length} selected`
            : `${selected.length} of ${options.length} selected`}
        </span>
        <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform flex-shrink-0 ml-2 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      
      {isOpen && (
        <div className="absolute z-[9999] top-full left-0 right-0 mt-1 bg-white border border-slate-200 rounded-xl shadow-2xl overflow-hidden">
          {/* Search */}
          <div className="p-2 border-b border-slate-100">
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full px-3 py-1.5 border border-slate-200 rounded-md text-xs focus:outline-none focus:ring-1 focus:ring-indigo-400"
              placeholder="Search..."
              autoFocus
            />
          </div>
          
          {/* Select All / Clear */}
          <div className="flex items-center justify-between px-3 py-1.5 border-b border-slate-100 bg-slate-50">
            <button onClick={toggleAll} className="text-xs font-semibold text-indigo-600 hover:text-indigo-800">
              {allSelected ? 'Deselect All' : 'Select All'}
            </button>
            {selected.length > 0 && (
              <button onClick={clearAll} className="text-xs font-semibold text-rose-600 hover:text-rose-800">
                Clear
              </button>
            )}
          </div>
          
          {/* Options */}
          <div className="overflow-y-auto" style={{ maxHeight }}>
            {filtered.length === 0 ? (
              <div className="px-3 py-4 text-center text-xs text-slate-400">No matches found</div>
            ) : filtered.map(option => (
              <label
                key={option.id}
                className="flex items-center gap-2.5 px-3 py-2 hover:bg-indigo-50 cursor-pointer transition-colors border-b border-slate-50 last:border-0"
              >
                <input
                  type="checkbox"
                  checked={selected.includes(option.id)}
                  onChange={() => toggle(option.id)}
                  className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-slate-800 font-medium truncate">{option.label}</p>
                  {option.sublabel && <p className="text-[10px] text-slate-400 truncate">{option.sublabel}</p>}
                </div>
                {option.count !== undefined && (
                  <span className="text-[10px] bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded font-medium">{option.count}</span>
                )}
              </label>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// Validate coordinates helper
const isValidCoord = (lat: number, long: number): boolean => {
  return (
    typeof lat === 'number' && typeof long === 'number' &&
    !isNaN(lat) && !isNaN(long) &&
    isFinite(lat) && isFinite(long) &&
    lat !== 0 && long !== 0 &&
    lat >= -90 && lat <= 90 &&
    long >= -180 && long <= 180
  );
};

// Map fit bounds component (only fits valid coordinates)
function MapBounds({ data }: { data: VisitRecord[] }) {
  const map = useMap();
  
  useEffect(() => {
    const validData = data.filter(d => isValidCoord(d.lat, d.long));
    if (validData.length > 0) {
      const bounds = new LatLngBounds(
        validData.map(d => [d.lat, d.long] as [number, number])
      );
      map.fitBounds(bounds, { padding: [50, 50], maxZoom: 16 });
    }
    // Force size recalculation when map mounts (fixes tab-switch sizing issues)
    setTimeout(() => map.invalidateSize(), 100);
  }, [data, map]);
  
  return null;
}

// Custom cluster icon creator
const createClusterIcon = (cluster: any) => {
  const count = cluster.getChildCount();
  let color = 'bg-emerald-500';
  let size = 36;
  if (count > 100) { color = 'bg-red-600'; size = 56; }
  else if (count > 50) { color = 'bg-rose-500'; size = 50; }
  else if (count > 20) { color = 'bg-amber-500'; size = 44; }
  else if (count > 10) { color = 'bg-indigo-500'; size = 40; }
  
  return divIcon({
    html: `<div class="${color} text-white font-bold rounded-full flex items-center justify-center shadow-lg border-2 border-white" style="width:${size}px;height:${size}px;font-size:${count > 99 ? '11px' : '13px'};">${count}</div>`,
    className: 'custom-cluster-icon',
    iconSize: point(size, size, true)
  });
};

export default function App() {
  const [currentUser, setCurrentUser] = useState<LoggedInUser | null>(null);
  const [authChecked, setAuthChecked] = useState(false);

  useEffect(() => {
    setCurrentUser(getCurrentSession());
    setAuthChecked(true);
  }, []);

  if (!authChecked) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-100">
        <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!currentUser) {
    return <LoginPage onLogin={setCurrentUser} />;
  }

  return <NationalGeoTracker currentUser={currentUser} />;
}

function NationalGeoTracker({ currentUser }: { currentUser: LoggedInUser }) {
  const isAdmin = currentUser.role === 'admin';
  // State
  const [activeTab, setActiveTab] = useState<'dashboard' | 'map' | 'analytics' | 'drilldown' | 'master' | 'security'>('dashboard');
  const [hierarchy, setHierarchy] = useState<HierarchyNode[]>(initialHierarchy);
  const [visitData, setVisitData] = useState<VisitRecord[]>([]);
  const [selectedLevel, setSelectedLevel] = useState<'national' | 'region' | 'area' | 'territory' | 'salesPoint'>('national');
  const [selectedIds, setSelectedIds] = useState<string[]>(['national-1']);
  const [dateRange, setDateRange] = useState<{ start: string; end: string }>(() => {
    const today = new Date();
    const thirtyDaysAgo = new Date(today);
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    return {
      start: format(thirtyDaysAgo, 'yyyy-MM-dd'),
      end: format(today, 'yyyy-MM-dd')
    };
  });
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set(['national-1']));
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadSalesPoint, setUploadSalesPoint] = useState<string>('');
  const [uploadDate, setUploadDate] = useState<string>(format(new Date(), 'yyyy-MM-dd'));
  const [masterEditMode, setMasterEditMode] = useState(false);
  const [newNodeForm, setNewNodeForm] = useState<{ name: string; type: HierarchyNode['type']; parentId: string; salesPointCode: string } | null>(null);
  
  // Cascading Drill Down States
  const [drillNational, setDrillNational] = useState<string>('national-1');
  const [drillRegions, setDrillRegions] = useState<string[]>(['ALL']);
  const [drillAreas, setDrillAreas] = useState<string[]>(['ALL']);
  const [drillTerritories, setDrillTerritories] = useState<string[]>(['ALL']);
  const [drillSalesPoints, setDrillSalesPoints] = useState<string[]>(['ALL']);
  const [drillRoutes, setDrillRoutes] = useState<string[]>(['ALL']);
  const [drillOutlet, setDrillOutlet] = useState<string>('ALL');
  
  // Map-specific filters
  const [mapShowFilter, setMapShowFilter] = useState<'all' | 'violations' | 'compliant'>('all');
  const [mapSalesPointFilter, setMapSalesPointFilter] = useState<string>('ALL');
  
  // Initialize data
  useEffect(() => {
    const saved = localStorage.getItem('geoTrackerData');
    
    if (saved) {
      const parsed: VisitRecord[] = JSON.parse(saved).map((row: Partial<VisitRecord>) => ({
        salesPointCode: row.salesPointCode || '',
        ...row,
      })) as VisitRecord[];
      setVisitData(parsed);
    } else {
      setVisitData([]);
    }
    
    const savedHierarchy = localStorage.getItem('geoHierarchy');
    if (savedHierarchy) {
      const parsedHierarchy: HierarchyNode[] = JSON.parse(savedHierarchy);
      parsedHierarchy.forEach((node) => {
        if (node.type === 'salesPoint') {
          node.salesPointCode = salesPointCodeMap[node.id] || node.salesPointCode || node.id.toUpperCase();
        }
      });
      setHierarchy(parsedHierarchy);
    }
  }, []);

  const getSalesPointLabel = useCallback((salesPointId: string) => {
    const node = hierarchy.find(n => n.id === salesPointId);
    if (!node) return salesPointId;
    return node.salesPointCode ? `${node.name} (${node.salesPointCode})` : node.name;
  }, [hierarchy]);

  const getChronologicalVisits = useCallback((visits: VisitRecord[]) => {
    return [...visits].sort((a, b) => {
      const dateDiff = a.visitDate.localeCompare(b.visitDate);
      return dateDiff !== 0 ? dateDiff : a.id.localeCompare(b.id);
    });
  }, []);

  const getDuplicateVisitStats = useCallback((visits: VisitRecord[]) => {
    const seenOutlets = new Set<string>();
    let duplicateVisits = 0;

    getChronologicalVisits(visits).forEach(v => {
      if (seenOutlets.has(v.outletCode)) {
        duplicateVisits++;
      } else {
        seenOutlets.add(v.outletCode);
      }
    });

    return {
      uniqueOutlets: seenOutlets.size,
      duplicateVisits,
    };
  }, [getChronologicalVisits]);
  
  // Save hierarchy changes
  useEffect(() => {
    localStorage.setItem('geoHierarchy', JSON.stringify(hierarchy));
  }, [hierarchy]);
  
  // Cascading Drill Down Computed Data
  const cascadingDrillData = useMemo(() => {
    // 1. Filter base visits by date range
    const baseVisits = visitData.filter(v => 
      v.visitDate >= dateRange.start && v.visitDate <= dateRange.end
    );

    // Filtered lists of hierarchy options
    const nationals = hierarchy.filter(n => n.type === 'national');
    
    const regions = drillNational === 'ALL' 
      ? hierarchy.filter(n => n.type === 'region')
      : hierarchy.filter(n => n.type === 'region' && n.parentId === drillNational);
    const regionIds = new Set(regions.map(r => r.id));

    const areas = drillRegions.includes('ALL')
      ? hierarchy.filter(n => n.type === 'area' && n.parentId && regionIds.has(n.parentId))
      : hierarchy.filter(n => n.type === 'area' && n.parentId && regionIds.has(n.parentId));
    const areaIds = new Set(areas.map(a => a.id));

    const territories = drillAreas.includes('ALL')
      ? hierarchy.filter(n => n.type === 'territory' && n.parentId && areaIds.has(n.parentId))
      : hierarchy.filter(n => n.type === 'territory' && n.parentId && areaIds.has(n.parentId));
    const territoryIds = new Set(territories.map(t => t.id));

    const salesPointsList = drillTerritories.includes('ALL')
      ? hierarchy.filter(n => n.type === 'salesPoint' && n.parentId && territoryIds.has(n.parentId))
      : hierarchy.filter(n => n.type === 'salesPoint' && n.parentId && territoryIds.has(n.parentId));
    const spIds = new Set(salesPointsList.map(sp => sp.id));

    // Filter visits down to the selected Sales Point(s)
    let spVisits = baseVisits.filter(v => spIds.has(v.salesPointId));
    if (!drillSalesPoints.includes('ALL')) {
      spVisits = spVisits.filter(v => drillSalesPoints.includes(v.salesPointId));
    }

    // Available Routes from these visits
    const routes = Array.from(new Set(spVisits.map(v => v.routeName))).sort();

    // Filter visits down to the selected Route(s)
    let routeVisits = spVisits;
    if (!drillRoutes.includes('ALL')) {
      routeVisits = routeVisits.filter(v => drillRoutes.includes(v.routeName));
    }

    // Available Outlets from these visits
    const outletsMap = new Map<string, { code: string; name: string; visitsCount: number }>();
    routeVisits.forEach(v => {
      if (!outletsMap.has(v.outletCode)) {
        outletsMap.set(v.outletCode, { code: v.outletCode, name: v.outletName, visitsCount: 0 });
      }
      outletsMap.get(v.outletCode)!.visitsCount++;
    });
    const outlets = Array.from(outletsMap.values()).sort((a, b) => a.name.localeCompare(b.name));

    // Final visits down to the selected Outlet
    let finalVisits = [...routeVisits];
    if (drillOutlet !== 'ALL') {
      finalVisits = finalVisits.filter(v => v.outletCode === drillOutlet);
    }
    
    // Sort final visits by visitDate descending
    finalVisits.sort((a, b) => b.visitDate.localeCompare(a.visitDate));

    return {
      nationals,
      regions,
      areas,
      territories,
      salesPointsList,
      routes,
      outlets,
      finalVisits
    };
  }, [visitData, dateRange, hierarchy, drillNational, drillRegions, drillAreas, drillTerritories, drillSalesPoints, drillRoutes, drillOutlet]);
  
  // Filtered data based on selection
  const filteredData = useMemo(() => {
    let filtered = visitData.filter(v => 
      v.visitDate >= dateRange.start && v.visitDate <= dateRange.end
    );
    
    if (selectedLevel === 'national') return filtered;
    if (selectedIds.length === 0) return filtered;
    
    // Get all descendant IDs for each selected node
    const getDescendants = (parentId: string): string[] => {
      const children = hierarchy.filter(n => n.parentId === parentId);
      const childIds = children.map(c => c.id);
      return [...childIds, ...childIds.flatMap(getDescendants)];
    };
    
    const allMatchIds = new Set<string>();
    selectedIds.forEach(id => {
      allMatchIds.add(id);
      getDescendants(id).forEach(descId => allMatchIds.add(descId));
    });
    
    switch (selectedLevel) {
      case 'region':
        return filtered.filter(v => allMatchIds.has(v.regionId));
      case 'area':
        return filtered.filter(v => allMatchIds.has(v.areaId));
      case 'territory':
        return filtered.filter(v => allMatchIds.has(v.territoryId));
      case 'salesPoint':
        return filtered.filter(v => allMatchIds.has(v.salesPointId));
      default:
        return filtered;
    }
  }, [visitData, selectedLevel, selectedIds, dateRange, hierarchy]);
  
  // KPI calculations
  const kpiData: KPIData = useMemo(() => {
    const totalVisits = filteredData.length;
    const { uniqueOutlets, duplicateVisits } = getDuplicateVisitStats(filteredData);
    const violations = filteredData.filter(v => v.distance > 30).length;
    
    return {
      totalVisits,
      uniqueOutlets,
      violations,
      duplicates: duplicateVisits,
      violationRate: totalVisits > 0 ? (violations / totalVisits) * 100 : 0,
      duplicateRate: totalVisits > 0 ? (duplicateVisits / totalVisits) * 100 : 0
    };
  }, [filteredData, getDuplicateVisitStats]);
  
  // Aggregated data for tables
  const aggregatedData = useMemo(() => {
    const aggregate = (keyFn: (v: VisitRecord) => string, nameFn: (v: VisitRecord) => string, type: string): AggregatedData[] => {
      const groups = new Map<string, { name: string; visits: VisitRecord[] }>();
      
      filteredData.forEach(v => {
        const key = keyFn(v);
        if (!groups.has(key)) {
          groups.set(key, { name: nameFn(v), visits: [] });
        }
        groups.get(key)!.visits.push(v);
      });
      
      return Array.from(groups.entries()).map(([key, { name, visits }]) => {
        const uniqueOutlets = new Set(visits.map(v => v.outletCode)).size;
        const violations = visits.filter(v => v.distance > 30).length;
        const duplicates = Math.max(0, visits.length - uniqueOutlets);
        
        return {
          key,
          name,
          totalVisits: visits.length,
          uniqueOutlets,
          violations,
          duplicates,
          type
        };
      }).sort((a, b) => b.totalVisits - a.totalVisits);
    };
    
    switch (selectedLevel) {
      case 'national':
        return aggregate(v => v.regionId, v => v.regionName, 'Region');
      case 'region':
        return aggregate(v => v.areaId, v => v.areaName, 'Area');
      case 'area':
        return aggregate(v => v.territoryId, v => v.territoryName, 'Territory');
      case 'territory':
        return aggregate(v => v.salesPointId, v => v.salesPointName, 'Sales Point');
      case 'salesPoint':
        return aggregate(v => v.routeName, v => v.routeName, 'Route');
      default:
        return [];
    }
  }, [filteredData, selectedLevel]);
  
  // Chart data
  const chartData = useMemo(() => {
    // Daily trend
    const days = eachDayOfInterval({
      start: parseISO(dateRange.start),
      end: parseISO(dateRange.end)
    });
    
    const dailyData = days.map(day => {
      const dateStr = format(day, 'yyyy-MM-dd');
      const dayVisits = filteredData.filter(v => v.visitDate === dateStr);
      return {
        date: format(day, 'MMM dd'),
        visits: dayVisits.length,
        violations: dayVisits.filter(v => v.distance > 30).length
      };
    });
    
    // Level comparison
    const levelData = aggregatedData.slice(0, 10).map(d => ({
      name: d.name.length > 15 ? d.name.substring(0, 15) + '...' : d.name,
      visits: d.totalVisits,
      violations: d.violations,
      duplicates: d.duplicates
    }));
    
    return { dailyData, levelData };
  }, [filteredData, dateRange, aggregatedData]);
  
  // Hierarchy tree helpers
  const toggleNode = (nodeId: string) => {
    setExpandedNodes(prev => {
      const next = new Set(prev);
      if (next.has(nodeId)) {
        next.delete(nodeId);
      } else {
        next.add(nodeId);
      }
      return next;
    });
  };
  
  const selectNode = (node: HierarchyNode, event: React.MouseEvent) => {
    setSelectedLevel(node.type);
    if (event.shiftKey || event.ctrlKey || event.metaKey) {
      // Multi-select: toggle this node
      setSelectedIds(prev =>
        prev.includes(node.id) ? prev.filter(id => id !== node.id) : [...prev, node.id]
      );
    } else {
      // Single select: replace with just this node
      setSelectedIds([node.id]);
    }
  };
  
  const getChildren = (parentId: string) => hierarchy.filter(n => n.parentId === parentId);
  
  const renderTree = (nodeId: string, level: number = 0) => {
    const node = hierarchy.find(n => n.id === nodeId);
    if (!node) return null;
    
    const children = getChildren(nodeId);
    const isExpanded = expandedNodes.has(nodeId);
    const isSelected = selectedIds.includes(nodeId);
    const hasChildren = children.length > 0;
    
    const icons = {
      national: Globe,
      region: Building2,
      area: Layers,
      territory: MapIcon,
      salesPoint: Store
    };
    
    const IconComponent = icons[node.type];
    const colors = {
      national: 'text-purple-600 bg-purple-50',
      region: 'text-blue-600 bg-blue-50',
      area: 'text-cyan-600 bg-cyan-50',
      territory: 'text-emerald-600 bg-emerald-50',
      salesPoint: 'text-amber-600 bg-amber-50'
    };
    
    return (
      <div key={nodeId}>
        <div 
          className={`flex items-center gap-2 py-2 px-3 rounded-lg cursor-pointer transition-all ${
            isSelected ? 'bg-indigo-100 border-l-4 border-indigo-600' : 'hover:bg-gray-50'
          }`}
          style={{ paddingLeft: `${level * 16 + 12}px` }}
          onClick={(e) => selectNode(node, e)}
        >
          {hasChildren && (
            <button
              onClick={(e) => { e.stopPropagation(); toggleNode(nodeId); }}
              className="p-1 hover:bg-gray-200 rounded"
            >
              {isExpanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
            </button>
          )}
          {!hasChildren && <span className="w-6" />}
          <div className={`p-1.5 rounded-md ${colors[node.type]}`}>
            <IconComponent size={16} />
          </div>
          <span className={`text-sm font-medium ${isSelected ? 'text-indigo-900' : 'text-gray-700'}`}>
            {node.name}
          </span>
          {node.type === 'salesPoint' && (
            <span className="ml-auto text-xs text-gray-400">
              {visitData.filter(v => v.salesPointId === nodeId).length} visits
            </span>
          )}
        </div>
        {isExpanded && children.map(child => renderTree(child.id, level + 1))}
      </div>
    );
  };
  
  // File upload handler
  const handleFileUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadFile(file);
    }
  }, []);
  
  const processUpload = useCallback(async () => {
    if (!uploadFile || !uploadSalesPoint || !uploadDate) {
      alert('Please select file, sales point, and date');
      return;
    }
    
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const jsonData = XLSX.utils.sheet_to_json(sheet);
        
        const sp = hierarchy.find(n => n.id === uploadSalesPoint);
        const territory = hierarchy.find(n => n.id === sp?.parentId);
        const area = hierarchy.find(n => n.id === territory?.parentId);
        const region = hierarchy.find(n => n.id === area?.parentId);
        const national = hierarchy.find(n => n.id === region?.parentId);
        
        const newRecords: VisitRecord[] = jsonData.map((row: any, idx: number) => ({
          id: `upload-${Date.now()}-${idx}`,
          salesPointId: uploadSalesPoint,
          salesPointName: sp?.name || '',
          salesPointCode: sp?.salesPointCode || salesPointCodeMap[uploadSalesPoint] || uploadSalesPoint,
          territoryId: territory?.id || '',
          territoryName: territory?.name || '',
          areaId: area?.id || '',
          areaName: area?.name || '',
          regionId: region?.id || '',
          regionName: region?.name || '',
          nationalId: national?.id || '',
          visitDate: uploadDate,
          routeName: row['Route Name'] || row['route'] || 'Unknown',
          outletCode: row['Outlet Code'] || row['outlet_code'] || `OUT-${idx}`,
          outletName: row['Outlet Name'] || row['outlet_name'] || `Outlet ${idx}`,
          distance: parseFloat(row['CheckIn Distance (meter)'] || row['distance'] || '0'),
          lat: parseFloat(row['Base Lat'] || row['lat'] || '23.8103'),
          long: parseFloat(row['Base Long'] || row['long'] || '90.4125')
        }));
        
        const updated = [...visitData, ...newRecords];
        setVisitData(updated);
        localStorage.setItem('geoTrackerData', JSON.stringify(updated));
        
        alert(`Successfully uploaded ${newRecords.length} records!`);
        setUploadFile(null);
      } catch (err) {
        alert('Error processing file. Please check the format.');
      }
    };
    reader.readAsArrayBuffer(uploadFile);
  }, [uploadFile, uploadSalesPoint, uploadDate, hierarchy, visitData]);
  
  // Master data management
  const addNode = () => {
    if (!newNodeForm?.name || !newNodeForm?.parentId) return;

    if (newNodeForm.type === 'salesPoint') {
      const code = newNodeForm.salesPointCode.trim();
      if (!code) {
        alert('Please enter a unique Sales Point Code.');
        return;
      }
      const duplicate = hierarchy.some(n => n.type === 'salesPoint' && n.salesPointCode?.toLowerCase() === code.toLowerCase());
      if (duplicate) {
        alert('Sales Point Code must be unique.');
        return;
      }
    }
    
    const newNode: HierarchyNode = {
      id: `${newNodeForm.type}-${Date.now()}`,
      name: newNodeForm.name,
      type: newNodeForm.type,
      parentId: newNodeForm.parentId,
      salesPointCode: newNodeForm.type === 'salesPoint' ? newNodeForm.salesPointCode.trim() : undefined
    };
    
    setHierarchy([...hierarchy, newNode]);
    
    // Auto-expand all ancestors of the new node so it's immediately visible in the sidebar tree
    const ancestorIds = new Set<string>();
    let currentParentId: string | null = newNode.parentId;
    while (currentParentId) {
      ancestorIds.add(currentParentId);
      const parentNode = hierarchy.find(n => n.id === currentParentId);
      currentParentId = parentNode?.parentId || null;
    }
    setExpandedNodes(prev => {
      const next = new Set(prev);
      ancestorIds.forEach(id => next.add(id));
      return next;
    });
    
    setNewNodeForm(null);
    
    const typeLabels: Record<string, string> = {
      national: 'National',
      region: 'Region',
      area: 'Area',
      territory: 'Territory',
      salesPoint: 'Sales Point'
    };
    alert(`✓ ${typeLabels[newNode.type]} "${newNode.name}" added successfully!\n\nIt is now visible in the hierarchy navigator. To see it in the Dashboard, upload visit data for this ${typeLabels[newNode.type].toLowerCase()}.`);
  };
  
  const deleteNode = (nodeId: string) => {
    if (!confirm('Are you sure you want to delete this node and all its children?')) return;
    
    const getDescendants = (id: string): string[] => {
      const children = hierarchy.filter(n => n.parentId === id);
      return [id, ...children.flatMap(c => getDescendants(c.id))];
    };
    
    const toDelete = new Set(getDescendants(nodeId));
    setHierarchy(hierarchy.filter(n => !toDelete.has(n.id)));
  };
  
  const getBreadcrumb = () => {
    const node = hierarchy.find(n => n.id === selectedIds[0]);
    if (!node) return [];
    
    const path: HierarchyNode[] = [node];
    let current = node;
    
    while (current.parentId) {
      const parent = hierarchy.find(n => n.id === current.parentId);
      if (parent) {
        path.unshift(parent);
        current = parent;
      } else {
        break;
      }
    }
    
    return path;
  };
  
  // Export functions
  const exportSummaryToExcel = () => {
    const rows = aggregatedData.map(d => ({
      'Unit Name': d.name,
      'Unit Type': d.type,
      'Total Visits': d.totalVisits,
      'Unique Outlets': d.uniqueOutlets,
      'Geo Violations': d.violations,
      'Duplicate Visits': d.duplicates
    }));
    
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Summary");
    XLSX.writeFile(wb, `GeoTracker_Summary_${selectedLevel}_${format(new Date(), 'yyyyMMdd')}.xlsx`);
  };

  // Removed unused exportDrillDownToExcel as custom cascading exports are placed directly in the panel
  
  const breadcrumb = getBreadcrumb();
  const salesPoints = hierarchy.filter(n => n.type === 'salesPoint');
  
  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Sidebar */}
      <aside className="w-80 bg-slate-900 text-white flex flex-col h-screen sticky top-0 overflow-hidden">
        <div className="p-6 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center">
              <MapPin className="text-white" size={20} />
            </div>
            <div>
              <h1 className="font-bold text-lg tracking-tight">GeoTracker Pro</h1>
              <p className="text-xs text-slate-400">National Level System</p>
            </div>
          </div>
        </div>
        
        {/* Hierarchy Tree */}
        <div className="flex-1 overflow-y-auto p-4">
          <div className="mb-4">
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Hierarchy Navigator</h3>
            <div className="bg-slate-800 rounded-xl p-2">
              {renderTree('national-1')}
            </div>
          </div>
          
          {/* Quick Upload */}
          <div className="mt-6">
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Quick Upload</h3>
            <div className="bg-slate-800 rounded-xl p-4 space-y-3">
              <select 
                className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-sm text-white"
                value={uploadSalesPoint}
                onChange={(e) => setUploadSalesPoint(e.target.value)}
              >
                <option value="">Select Sales Point</option>
                {salesPoints.map(sp => (
                  <option key={sp.id} value={sp.id}>{getSalesPointLabel(sp.id)}</option>
                ))}
              </select>
              <input
                type="date"
                className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-sm text-white"
                value={uploadDate}
                onChange={(e) => setUploadDate(e.target.value)}
              />
              <label className="flex items-center justify-center gap-2 w-full bg-slate-700 border border-dashed border-slate-500 rounded-lg px-3 py-3 text-sm text-slate-300 cursor-pointer hover:bg-slate-600 transition-colors">
                <Upload size={16} />
                {uploadFile ? uploadFile.name : 'Choose Excel File'}
                <input type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={handleFileUpload} />
              </label>
              <button
                onClick={processUpload}
                disabled={!uploadFile || !uploadSalesPoint}
                className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-700 disabled:cursor-not-allowed text-white font-medium py-2 rounded-lg text-sm transition-colors"
              >
                Sync to Database
              </button>
            </div>
          </div>
        </div>
        
        {/* KPI Summary in Sidebar */}
        <div className="p-4 border-t border-slate-800 bg-slate-800/50">
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-slate-800 rounded-lg p-3">
              <p className="text-xs text-slate-400">Total Visits</p>
              <p className="text-xl font-bold text-white">{kpiData.totalVisits.toLocaleString()}</p>
            </div>
            <div className="bg-slate-800 rounded-lg p-3">
              <p className="text-xs text-slate-400">Violations</p>
              <p className={`text-xl font-bold ${kpiData.violations > 0 ? 'text-red-400' : 'text-emerald-400'}`}>
                {kpiData.violations}
              </p>
            </div>
          </div>
        </div>
      </aside>
      
      {/* Main Content */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Header */}
        <header className="bg-white border-b border-slate-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              {/* Breadcrumb */}
              <nav className="flex items-center gap-2 text-sm mb-1">
                {breadcrumb.map((node, idx) => (
                  <React.Fragment key={node.id}>
                    {idx > 0 && <ChevronRight size={14} className="text-slate-400" />}
                    <button
                      onClick={() => { setSelectedLevel(node.type); setSelectedIds([node.id]); }}
                      className={`${idx === breadcrumb.length - 1 ? 'text-slate-900 font-semibold' : 'text-slate-500 hover:text-slate-700'}`}
                    >
                      {node.name}
                    </button>
                  </React.Fragment>
                ))}
              </nav>
              <h2 className="text-2xl font-bold text-slate-900">
                {breadcrumb[breadcrumb.length - 1]?.name} Dashboard
              </h2>
            </div>
            
            <div className="flex items-center gap-3">
              {/* Date Range */}
              <div className="flex items-center gap-2 bg-slate-100 rounded-lg p-1">
                <input
                  type="date"
                  className="bg-transparent border-none text-sm px-2 py-1 outline-none"
                  value={dateRange.start}
                  onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
                />
                <span className="text-slate-400">to</span>
                <input
                  type="date"
                  className="bg-transparent border-none text-sm px-2 py-1 outline-none"
                  value={dateRange.end}
                  onChange={(e) => setDateRange({ ...dateRange, end: e.target.value })}
                />
              </div>
              
              <button
                onClick={() => {
                  if (confirm('Are you sure you want to remove all demo data and refresh the workspace?')) {
                    localStorage.setItem('geoTrackerData', JSON.stringify([]));
                    localStorage.setItem('demoRemoved', 'true');
                    window.location.reload();
                  }
                }}
                className="flex items-center gap-2 px-3 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg text-xs font-bold transition-colors border border-rose-200 shadow-sm"
                title="Completely clear all demo data and refresh the workspace"
              >
                <RefreshCw size={16} />
                Refresh & Clear Demo Data
              </button>

              <button
                onClick={() => {
                  if (confirm('Load 30 days of sample data for testing?')) {
                    localStorage.removeItem('demoRemoved');
                    const sample = generateSampleData();
                    setVisitData(sample);
                    localStorage.setItem('geoTrackerData', JSON.stringify(sample));
                    window.location.reload();
                  }
                }}
                className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg text-xs font-medium transition-colors border border-slate-200"
                title="Load sample testing data"
              >
                Load Demo Data
              </button>

              {/* User Profile & Logout */}
              <div className="flex items-center gap-2 pl-3 ml-1 border-l border-slate-200">
                <div className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-white text-sm ${
                  isAdmin ? 'bg-gradient-to-br from-purple-500 to-indigo-600' : 'bg-gradient-to-br from-emerald-500 to-teal-600'
                }`} title={`${currentUser.fullName} (${currentUser.role})`}>
                  {currentUser.fullName.charAt(0).toUpperCase()}
                </div>
                <div className="text-xs">
                  <p className="font-semibold text-slate-900 leading-tight">{currentUser.fullName}</p>
                  <p className="text-slate-500 capitalize">{currentUser.role}</p>
                </div>
                <button
                  onClick={() => {
                    if (confirm('Are you sure you want to log out?')) logout();
                  }}
                  className="flex items-center gap-1 px-2.5 py-1.5 bg-red-50 hover:bg-red-100 text-red-700 rounded-lg text-xs font-bold transition-colors border border-red-200"
                  title="Sign out"
                >
                  <LogOut size={14} />
                  Logout
                </button>
              </div>
            </div>
          </div>
          
          {/* Tabs */}
          <div className="flex items-center gap-1 mt-4">
            {[
              { id: 'dashboard', label: 'Dashboard', icon: BarChart3, adminOnly: false },
              { id: 'map', label: 'Live Map', icon: MapIcon, adminOnly: false },
              { id: 'analytics', label: 'Analytics', icon: TrendingUp, adminOnly: false },
              { id: 'drilldown', label: 'Drill Down', icon: Search, adminOnly: false },
              { id: 'master', label: 'Master Data', icon: Database, adminOnly: true },
              { id: 'security', label: 'Security', icon: Shield, adminOnly: true }
            ].filter(tab => !tab.adminOnly || isAdmin).map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  activeTab === tab.id
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <tab.icon size={16} />
                {tab.label}
              </button>
            ))}
          </div>
        </header>
        
        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-6">
          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              {/* KPI Cards */}
              <div className="grid grid-cols-4 gap-4">
                <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3 bg-indigo-50 rounded-lg">
                      <Users className="text-indigo-600" size={24} />
                    </div>
                    <span className="text-xs font-medium text-emerald-600 bg-emerald-50 px-2 py-1 rounded-full">
                      +12.5%
                    </span>
                  </div>
                  <p className="text-sm text-slate-500 mb-1">Total Visits</p>
                  <p className="text-3xl font-bold text-slate-900">{kpiData.totalVisits.toLocaleString()}</p>
                </div>
                
                <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3 bg-emerald-50 rounded-lg">
                      <Store className="text-emerald-600" size={24} />
                    </div>
                  </div>
                  <p className="text-sm text-slate-500 mb-1">Unique Outlets</p>
                  <p className="text-3xl font-bold text-slate-900">{kpiData.uniqueOutlets.toLocaleString()}</p>
                </div>
                
                <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3 bg-amber-50 rounded-lg">
                      <AlertTriangle className="text-amber-600" size={24} />
                    </div>
                    <span className={`text-xs font-medium px-2 py-1 rounded-full ${
                      kpiData.violationRate > 10 ? 'text-red-600 bg-red-50' : 'text-emerald-600 bg-emerald-50'
                    }`}>
                      {kpiData.violationRate.toFixed(1)}%
                    </span>
                  </div>
                  <p className="text-sm text-slate-500 mb-1">Geo Violations</p>
                  <p className="text-3xl font-bold text-slate-900">{kpiData.violations}</p>
                </div>
                
                <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3 bg-rose-50 rounded-lg">
                      <XCircle className="text-rose-600" size={24} />
                    </div>
                    <span className={`text-xs font-medium px-2 py-1 rounded-full ${
                      kpiData.duplicateRate > 5 ? 'text-red-600 bg-red-50' : 'text-emerald-600 bg-emerald-50'
                    }`}>
                      {kpiData.duplicateRate.toFixed(1)}%
                    </span>
                  </div>
                  <p className="text-sm text-slate-500 mb-1">Duplicate Visits</p>
                  <p className="text-3xl font-bold text-slate-900">{kpiData.duplicates}</p>
                </div>
              </div>
              
              {/* Charts Row */}
              <div className="grid grid-cols-2 gap-6">
                <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
                  <h3 className="text-lg font-semibold text-slate-900 mb-4">Daily Visit Trend</h3>
                  <ResponsiveContainer width="100%" height={250}>
                    <AreaChart data={chartData.dailyData}>
                      <defs>
                        <linearGradient id="colorVisits" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                      <XAxis dataKey="date" tick={{ fontSize: 12 }} stroke="#64748b" />
                      <YAxis tick={{ fontSize: 12 }} stroke="#64748b" />
                      <Tooltip 
                        contentStyle={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px' }}
                      />
                      <Area type="monotone" dataKey="visits" stroke="#6366f1" fillOpacity={1} fill="url(#colorVisits)" />
                      <Area type="monotone" dataKey="violations" stroke="#ef4444" fill="none" strokeDasharray="5 5" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
                
                <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
                  <h3 className="text-lg font-semibold text-slate-900 mb-4">Top Performing {aggregatedData[0]?.type || 'Units'}</h3>
                  <ResponsiveContainer width="100%" height={250}>
                    <BarChart data={chartData.levelData} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                      <XAxis type="number" tick={{ fontSize: 12 }} stroke="#64748b" />
                      <YAxis dataKey="name" type="category" width={100} tick={{ fontSize: 11 }} stroke="#64748b" />
                      <Tooltip contentStyle={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px' }} />
                      <Legend />
                      <Bar dataKey="visits" fill="#6366f1" name="Visits" radius={[0, 4, 4, 0]} />
                      <Bar dataKey="violations" fill="#ef4444" name="Violations" radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
              
              {/* Data Table */}
              <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-slate-900">
                    {aggregatedData[0]?.type || 'Unit'} Performance Summary
                  </h3>
                  <button 
                    onClick={exportSummaryToExcel}
                    className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-sm font-medium transition-colors"
                  >
                    <FileSpreadsheet size={16} />
                    Export Excel
                  </button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-slate-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Name</th>
                        <th className="px-6 py-3 text-right text-xs font-semibold text-slate-500 uppercase">Total Visits</th>
                        <th className="px-6 py-3 text-right text-xs font-semibold text-slate-500 uppercase">Unique Outlets</th>
                        <th className="px-6 py-3 text-right text-xs font-semibold text-slate-500 uppercase">Violations</th>
                        <th className="px-6 py-3 text-right text-xs font-semibold text-slate-500 uppercase">Duplicate Visits</th>
                        <th className="px-6 py-3 text-center text-xs font-semibold text-slate-500 uppercase">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {aggregatedData.map((row) => (
                        <tr key={row.key} className="hover:bg-slate-50">
                          <td className="px-6 py-4 font-medium text-slate-900">{row.name}</td>
                          <td className="px-6 py-4 text-right text-slate-600">{row.totalVisits.toLocaleString()}</td>
                          <td className="px-6 py-4 text-right text-slate-600">{row.uniqueOutlets.toLocaleString()}</td>
                          <td className="px-6 py-4 text-right">
                            <span className={`font-medium ${row.violations > 0 ? 'text-red-600' : 'text-emerald-600'}`}>
                              {row.violations}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-right">
                            <span className={`font-medium ${row.duplicates > 0 ? 'text-amber-600' : 'text-emerald-600'}`}>
                              {row.duplicates}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-center">
                            <button
                              onClick={() => {
                                const node = hierarchy.find(n => n.id === row.key);
                                if (node) {
                                  setSelectedLevel(node.type);
                                  setSelectedIds([node.id]);
                                  setActiveTab('drilldown');
                                }
                              }}
                              className="inline-flex items-center gap-1 px-3 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg text-sm transition-colors"
                            >
                              <Eye size={14} />
                              View
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
          
          {activeTab === 'map' && (() => {
            // Filter map data based on validity & user filters
            const validMapData = filteredData.filter(v => isValidCoord(v.lat, v.long));
            
            let mapData = validMapData;
            if (mapShowFilter === 'violations') mapData = mapData.filter(v => v.distance > 30);
            if (mapShowFilter === 'compliant') mapData = mapData.filter(v => v.distance <= 30);
            if (mapSalesPointFilter !== 'ALL') mapData = mapData.filter(v => v.salesPointId === mapSalesPointFilter);
            
            const violationCount = validMapData.filter(v => v.distance > 30).length;
            const compliantCount = validMapData.length - violationCount;
            const invalidCount = filteredData.length - validMapData.length;
            const uniqueSalesPointsOnMap = Array.from(new Set(validMapData.map(v => v.salesPointId)))
              .map(id => hierarchy.find(n => n.id === id))
              .filter(Boolean);
            
            return (
              <div className="space-y-4">
                {/* Map Controls Bar */}
                <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
                  <div className="flex items-center justify-between flex-wrap gap-3">
                    <div className="flex items-center gap-3 flex-wrap">
                      <div className="flex items-center gap-2">
                        <MapIcon className="w-5 h-5 text-indigo-600" />
                        <span className="text-sm font-semibold text-slate-900">Map Filters:</span>
                      </div>
                      
                      {/* Show Filter */}
                      <div className="flex items-center gap-1 bg-slate-100 rounded-lg p-1">
                        {[
                          { value: 'all' as const, label: 'All', count: validMapData.length, color: 'indigo' },
                          { value: 'compliant' as const, label: 'Compliant', count: compliantCount, color: 'emerald' },
                          { value: 'violations' as const, label: 'Violations', count: violationCount, color: 'red' }
                        ].map(opt => (
                          <button
                            key={opt.value}
                            onClick={() => setMapShowFilter(opt.value)}
                            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${
                              mapShowFilter === opt.value
                                ? `bg-${opt.color}-600 text-white shadow-sm`
                                : 'text-slate-600 hover:bg-white'
                            }`}
                          >
                            {opt.label} ({opt.count})
                          </button>
                        ))}
                      </div>
                      
                      {/* Sales Point Filter */}
                      <select
                        value={mapSalesPointFilter}
                        onChange={(e) => setMapSalesPointFilter(e.target.value)}
                        className="text-xs border border-slate-300 rounded-lg px-3 py-1.5 bg-white font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      >
                        <option value="ALL">All Sales Points ({uniqueSalesPointsOnMap.length})</option>
                        {uniqueSalesPointsOnMap.map((sp: any) => (
                          <option key={sp.id} value={sp.id}>
                            {sp.name} {sp.salesPointCode ? `(${sp.salesPointCode})` : ''}
                          </option>
                        ))}
                      </select>
                    </div>
                    
                    {/* Stats */}
                    <div className="flex items-center gap-2 text-xs">
                      <div className="px-3 py-1.5 bg-emerald-50 border border-emerald-200 rounded-lg">
                        <span className="font-bold text-emerald-700">{mapData.length}</span>
                        <span className="text-emerald-600 ml-1">visible markers</span>
                      </div>
                      {invalidCount > 0 && (
                        <div className="px-3 py-1.5 bg-amber-50 border border-amber-200 rounded-lg" title="Records without valid GPS coordinates">
                          <AlertTriangle className="w-3 h-3 inline text-amber-600 mr-1" />
                          <span className="font-bold text-amber-700">{invalidCount}</span>
                          <span className="text-amber-600 ml-1">invalid coords</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Map Container */}
                {mapData.length === 0 ? (
                  <div className="bg-white rounded-xl shadow-sm border border-slate-200 flex items-center justify-center" style={{ height: 'calc(100vh - 280px)' }}>
                    <div className="text-center max-w-md p-8">
                      <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-slate-100 mb-4">
                        <MapIcon className="w-10 h-10 text-slate-400" />
                      </div>
                      <h3 className="text-lg font-bold text-slate-900 mb-2">No Map Data Available</h3>
                      <p className="text-sm text-slate-500 mb-4">
                        {filteredData.length === 0 
                          ? 'Upload visit data with valid GPS coordinates to see them on the map.'
                          : invalidCount > 0
                          ? `${invalidCount} records have invalid or missing GPS coordinates. Please ensure your Excel has valid Base Lat & Base Long values.`
                          : 'No records match the current filters. Try adjusting the filters above.'}
                      </p>
                      {filteredData.length === 0 && (
                        <p className="text-xs text-slate-400 italic">
                          Tip: Use the sidebar's "Sync to Database" to upload your Excel file.
                        </p>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden relative" style={{ height: 'calc(100vh - 280px)' }}>
                    {/* Legend Overlay */}
                    <div className="absolute top-3 right-3 z-[400] bg-white rounded-lg shadow-lg border border-slate-200 p-3">
                      <p className="text-xs font-bold text-slate-700 mb-2 uppercase tracking-wider">Legend</p>
                      <div className="space-y-1.5">
                        <div className="flex items-center gap-2 text-xs">
                          <div className="w-4 h-4 rounded-full bg-emerald-500 shadow-sm" />
                          <span className="text-slate-700">Compliant (≤30m)</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs">
                          <div className="w-4 h-4 rounded-full bg-red-600 shadow-sm" />
                          <span className="text-slate-700">Violation (&gt;30m)</span>
                        </div>
                        <div className="border-t border-slate-200 pt-1.5 mt-1.5">
                          <p className="text-[10px] text-slate-500 italic">Numbered circles = clusters</p>
                        </div>
                      </div>
                    </div>
                    
                    <MapContainer
                      key={`${mapShowFilter}-${mapSalesPointFilter}`}
                      center={[23.8103, 90.4125]}
                      zoom={7}
                      style={{ height: '100%', width: '100%' }}
                      scrollWheelZoom={true}
                    >
                      <TileLayer
                        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                        maxZoom={19}
                      />
                      <MapBounds data={mapData} />
                      <MarkerClusterGroup
                        chunkedLoading
                        iconCreateFunction={createClusterIcon}
                        maxClusterRadius={60}
                        spiderfyOnMaxZoom={true}
                        showCoverageOnHover={false}
                        zoomToBoundsOnClick={true}
                      >
                        {mapData.map((visit) => (
                          <Marker
                            key={visit.id}
                            position={[visit.lat, visit.long]}
                            icon={visit.distance > 30 ? violationIcon : defaultIcon}
                          >
                            <Popup maxWidth={280}>
                              <div className="p-1 min-w-[220px]">
                                <div className="flex items-start justify-between gap-2 pb-2 mb-2 border-b border-slate-200">
                                  <div>
                                    <h4 className="font-bold text-slate-900 leading-tight">{visit.outletName}</h4>
                                    <p className="text-xs text-slate-400 font-mono mt-0.5">{visit.outletCode}</p>
                                  </div>
                                  {visit.distance > 30 ? (
                                    <span className="bg-red-100 text-red-700 px-2 py-0.5 rounded text-[10px] font-bold flex items-center gap-1 whitespace-nowrap">
                                      <AlertTriangle size={10} />
                                      VIOLATION
                                    </span>
                                  ) : (
                                    <span className="bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded text-[10px] font-bold whitespace-nowrap">
                                      OK
                                    </span>
                                  )}
                                </div>
                                <div className="space-y-1 text-xs">
                                  <div className="flex justify-between gap-2">
                                    <span className="text-slate-500">Date:</span>
                                    <span className="font-semibold text-slate-900">{visit.visitDate}</span>
                                  </div>
                                  <div className="flex justify-between gap-2">
                                    <span className="text-slate-500">Sales Point:</span>
                                    <span className="font-semibold text-slate-900 text-right">
                                      {visit.salesPointName}
                                      {visit.salesPointCode && <span className="block text-[10px] text-slate-400 font-mono">{visit.salesPointCode}</span>}
                                    </span>
                                  </div>
                                  <div className="flex justify-between gap-2">
                                    <span className="text-slate-500">Route:</span>
                                    <span className="font-semibold text-slate-900">{visit.routeName}</span>
                                  </div>
                                  <div className="flex justify-between gap-2">
                                    <span className="text-slate-500">Territory:</span>
                                    <span className="font-semibold text-slate-900">{visit.territoryName}</span>
                                  </div>
                                  <div className="flex justify-between gap-2">
                                    <span className="text-slate-500">Distance:</span>
                                    <span className={`font-bold ${visit.distance > 30 ? 'text-red-600' : 'text-emerald-600'}`}>
                                      {visit.distance.toFixed(1)}m
                                    </span>
                                  </div>
                                  <div className="flex justify-between gap-2 pt-1 mt-1 border-t border-slate-100">
                                    <span className="text-slate-400 text-[10px]">GPS:</span>
                                    <span className="font-mono text-[10px] text-slate-500">{visit.lat.toFixed(5)}, {visit.long.toFixed(5)}</span>
                                  </div>
                                </div>
                              </div>
                            </Popup>
                          </Marker>
                        ))}
                      </MarkerClusterGroup>
                    </MapContainer>
                  </div>
                )}
              </div>
            );
          })()}
          
          {activeTab === 'analytics' && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
                  <h3 className="text-lg font-semibold text-slate-900 mb-4">Violation Analysis</h3>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={[
                          { name: 'Compliant', value: kpiData.totalVisits - kpiData.violations, color: '#10b981' },
                          { name: 'Violations', value: kpiData.violations, color: '#ef4444' }
                        ]}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {[
                          { name: 'Compliant', value: kpiData.totalVisits - kpiData.violations, color: '#10b981' },
                          { name: 'Violations', value: kpiData.violations, color: '#ef4444' }
                        ].map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                
                <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
                  <h3 className="text-lg font-semibold text-slate-900 mb-4">Visit Quality Metrics</h3>
                  <div className="space-y-4">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-slate-600">Compliance Rate</span>
                        <span className="text-sm font-semibold text-slate-900">
                          {((kpiData.totalVisits - kpiData.violations) / kpiData.totalVisits * 100).toFixed(1)}%
                        </span>
                      </div>
                      <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-emerald-500 rounded-full"
                          style={{ width: `${((kpiData.totalVisits - kpiData.violations) / kpiData.totalVisits * 100)}%` }}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-slate-600">Unique Visit Rate</span>
                        <span className="text-sm font-semibold text-slate-900">
                          {((kpiData.totalVisits - kpiData.duplicates) / kpiData.totalVisits * 100).toFixed(1)}%
                        </span>
                      </div>
                      <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-indigo-500 rounded-full"
                          style={{ width: `${((kpiData.totalVisits - kpiData.duplicates) / kpiData.totalVisits * 100)}%` }}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-slate-600">Outlet Coverage</span>
                        <span className="text-sm font-semibold text-slate-900">
                          {kpiData.uniqueOutlets} outlets
                        </span>
                      </div>
                      <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
                        <div className="h-full bg-amber-500 rounded-full" style={{ width: '75%' }} />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
                <h3 className="text-lg font-semibold text-slate-900 mb-4">Monthly Comparison</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={chartData.dailyData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="date" tick={{ fontSize: 12 }} stroke="#64748b" />
                    <YAxis tick={{ fontSize: 12 }} stroke="#64748b" />
                    <Tooltip contentStyle={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px' }} />
                    <Legend />
                    <Line type="monotone" dataKey="visits" stroke="#6366f1" strokeWidth={2} name="Total Visits" />
                    <Line type="monotone" dataKey="violations" stroke="#ef4444" strokeWidth={2} name="Violations" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}
          
          {activeTab === 'drilldown' && (
            <div className="space-y-6">
              <div className="grid grid-cols-4 gap-6">
                {/* 7-Level Cascading Filters Panel */}
                <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-200 space-y-4">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                    <h3 className="font-semibold text-slate-900 text-sm uppercase tracking-wider">Cascading Drill Filters</h3>
                    <button 
                      onClick={() => {
                        setDrillNational('national-1');
                        setDrillRegions(['ALL']);
                        setDrillAreas(['ALL']);
                        setDrillTerritories(['ALL']);
                        setDrillSalesPoints(['ALL']);
                        setDrillRoutes(['ALL']);
                        setDrillOutlet('ALL');
                      }}
                      className="text-xs text-indigo-600 hover:text-indigo-800 font-medium"
                    >
                      Reset All
                    </button>
                  </div>
                  
                  {/* 1. National */}
                  <div>
                    <label className="block text-xs font-bold text-slate-600 uppercase mb-1">1. National</label>
                    <select 
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-sm font-medium text-slate-800 outline-none focus:border-indigo-500"
                      value={drillNational}
                      onChange={(e) => {
                        setDrillNational(e.target.value);
                        setDrillRegions(['ALL']);
                        setDrillAreas(['ALL']);
                        setDrillTerritories(['ALL']);
                        setDrillSalesPoints(['ALL']);
                        setDrillRoutes(['ALL']);
                        setDrillOutlet('ALL');
                      }}
                    >
                      <option value="ALL">All Nationals</option>
                      {cascadingDrillData.nationals.map(n => (
                        <option key={n.id} value={n.id}>{n.name}</option>
                      ))}
                    </select>
                  </div>

                  {/* 2. Region (Multi) */}
                  <div>
                    <label className="block text-xs font-bold text-slate-600 uppercase mb-1">2. Region</label>
                    <MultiSelect
                      options={[{ id: 'ALL', label: 'All Regions' }].concat(cascadingDrillData.regions.map(r => ({ id: r.id, label: r.name })))}
                      selected={drillRegions}
                      onChange={(sel) => { setDrillRegions(sel); setDrillAreas(['ALL']); setDrillTerritories(['ALL']); setDrillSalesPoints(['ALL']); setDrillRoutes(['ALL']); setDrillOutlet('ALL'); }}
                      placeholder="Select Regions..."
                    />
                  </div>

                  {/* 3. Area (Multi) */}
                  <div>
                    <label className="block text-xs font-bold text-slate-600 uppercase mb-1">3. Area</label>
                    <MultiSelect
                      options={[{ id: 'ALL', label: 'All Areas' }].concat(cascadingDrillData.areas.map(a => ({ id: a.id, label: a.name })))}
                      selected={drillAreas}
                      onChange={(sel) => { setDrillAreas(sel); setDrillTerritories(['ALL']); setDrillSalesPoints(['ALL']); setDrillRoutes(['ALL']); setDrillOutlet('ALL'); }}
                      placeholder="Select Areas..."
                    />
                  </div>

                  {/* 4. Territory (Multi) */}
                  <div>
                    <label className="block text-xs font-bold text-slate-600 uppercase mb-1">4. Territory</label>
                    <MultiSelect
                      options={[{ id: 'ALL', label: 'All Territories' }].concat(cascadingDrillData.territories.map(t => ({ id: t.id, label: t.name })))}
                      selected={drillTerritories}
                      onChange={(sel) => { setDrillTerritories(sel); setDrillSalesPoints(['ALL']); setDrillRoutes(['ALL']); setDrillOutlet('ALL'); }}
                      placeholder="Select Territories..."
                    />
                  </div>

                  {/* 5. Sales Point (Multi) */}
                  <div>
                    <label className="block text-xs font-bold text-slate-600 uppercase mb-1">5. Sales Point</label>
                    <MultiSelect
                      options={[{ id: 'ALL', label: 'All Sales Points' }].concat(cascadingDrillData.salesPointsList.map(sp => ({ id: sp.id, label: getSalesPointLabel(sp.id) })))}
                      selected={drillSalesPoints}
                      onChange={(sel) => { setDrillSalesPoints(sel); setDrillRoutes(['ALL']); setDrillOutlet('ALL'); }}
                      placeholder="Select Sales Points..."
                    />
                  </div>

                  {/* 6. Route (Multi) */}
                  <div>
                    <label className="block text-xs font-bold text-slate-600 uppercase mb-1">6. Route Wise</label>
                    <MultiSelect
                      options={[{ id: 'ALL', label: 'All Routes' }].concat(cascadingDrillData.routes.map(rt => ({ id: rt, label: rt })))}
                      selected={drillRoutes}
                      onChange={(sel) => { setDrillRoutes(sel); setDrillOutlet('ALL'); }}
                      placeholder="Select Routes..."
                    />
                  </div>

                  {/* 7. Outlet (Single still) */}
                  <div>
                    <label className="block text-xs font-bold text-slate-600 uppercase mb-1">7. Outlets</label>
                    <select 
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-sm font-medium text-slate-800 outline-none focus:border-indigo-500"
                      value={drillOutlet}
                      onChange={(e) => setDrillOutlet(e.target.value)}
                    >
                      <option value="ALL">All Outlets ({cascadingDrillData.outlets.length})</option>
                      {cascadingDrillData.outlets.map(o => (
                        <option key={o.code} value={o.code}>{o.name} ({o.code})</option>
                      ))}
                    </select>
                  </div>
                  
                  {/* Cascading View Export Buttons */}
                  <div className="pt-3 border-t border-slate-200 space-y-2">
                    <button
                      onClick={() => {
                        const rows = cascadingDrillData.finalVisits.map(v => ({
                          'Visit Date': v.visitDate,
                          'National': hierarchy.find(n => n.id === v.nationalId)?.name || 'Bangladesh',
                          'Region': v.regionName,
                          'Area': v.areaName,
                          'Territory': v.territoryName,
                          'Sales Point Code': v.salesPointCode,
                          'Sales Point': v.salesPointName,
                          'Route Name': v.routeName,
                          'Outlet Code': v.outletCode,
                          'Outlet Name': v.outletName,
                          'Check-in Distance (m)': v.distance,
                          'Status': v.distance > 30 ? 'Violation (>30m)' : 'OK',
                          'Latitude': v.lat,
                          'Longitude': v.long
                        }));
                        
                        const ws = XLSX.utils.json_to_sheet(rows);
                        const wb = XLSX.utils.book_new();
                        XLSX.utils.book_append_sheet(wb, ws, "Cascading Visits");
                        XLSX.writeFile(wb, `GeoTracker_CascadingVisits_${format(new Date(), 'yyyyMMdd')}.xlsx`);
                      }}
                      className="w-full flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-medium py-2 px-3 rounded-lg text-xs transition-colors"
                    >
                      <FileSpreadsheet size={14} />
                      Export Active Visits ({cascadingDrillData.finalVisits.length})
                    </button>

                    <button
                      onClick={() => {
                        const outletStats = new Map<string, {
                          name: string;
                          route: string;
                          salesPoint: string;
                          visits: number;
                          totalDistance: number;
                          violations: number;
                          datesSeen: Map<string, number>;
                        }>();
                        
                        cascadingDrillData.finalVisits.forEach(v => {
                          if (!outletStats.has(v.outletCode)) {
                            outletStats.set(v.outletCode, {
                              name: v.outletName,
                              route: v.routeName,
                                salesPoint: `${v.salesPointName} (${v.salesPointCode})`,
                              visits: 0,
                              totalDistance: 0,
                              violations: 0,
                              datesSeen: new Map<string, number>()
                            });
                          }
                          const stat = outletStats.get(v.outletCode)!;
                          stat.visits++;
                          stat.totalDistance += v.distance;
                          if (v.distance > 30) stat.violations++;
                          stat.datesSeen.set(v.visitDate, (stat.datesSeen.get(v.visitDate) || 0) + 1);
                        });
                        
                        const rows = Array.from(outletStats.entries()).map(([code, stat]) => {
                          const duplicateVisits = Math.max(0, stat.visits - 1);
                            
                          return {
                            'Sales Point Code': cascadingDrillData.finalVisits.find(v => v.outletCode === code)?.salesPointCode || '',
                            'Sales Point': stat.salesPoint,
                            'Route Name': stat.route,
                            'Outlet Code': code,
                            'Outlet Name': stat.name,
                            'Total Visits': stat.visits,
                            'Average Distance (m)': Math.round((stat.totalDistance / stat.visits) * 10) / 10,
                            'Geo Violations': stat.violations,
                            'Duplicate Visits': duplicateVisits
                          };
                        });
                        
                        const ws = XLSX.utils.json_to_sheet(rows);
                        const wb = XLSX.utils.book_new();
                        XLSX.utils.book_append_sheet(wb, ws, "Outlet Summaries");
                        XLSX.writeFile(wb, `GeoTracker_CascadingOutlets_${format(new Date(), 'yyyyMMdd')}.xlsx`);
                      }}
                      className="w-full flex items-center justify-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium py-2 px-3 rounded-lg text-xs transition-colors"
                    >
                      <FileSpreadsheet size={14} />
                      Export Outlets Summary ({cascadingDrillData.outlets.length})
                    </button>
                  </div>
                </div>

                {/* Dynamic Drill Down Content Panel */}
                <div className="col-span-3 bg-white rounded-xl p-6 shadow-sm border border-slate-200 flex flex-col">
                  {(() => {
                    // Determine the deepest active filter level
                    let activeLevel: 'national' | 'region' | 'area' | 'territory' | 'salesPoint' | 'route' | 'outlet' = 'national';
                    let activeName = 'National Overview';
                    
                    if (drillOutlet !== 'ALL') {
                      activeLevel = 'outlet';
                      const foundOutlet = cascadingDrillData.outlets.find(o => o.code === drillOutlet);
                      activeName = `Outlet Detail: ${foundOutlet?.name || drillOutlet}`;
                    } else if (!drillRoutes.includes('ALL')) {
                      activeLevel = 'route';
                      activeName = `Route Overview: ${drillRoutes.length} route(s) selected`;
                    } else if (!drillSalesPoints.includes('ALL')) {
                      activeLevel = 'salesPoint';
                      activeName = `Sales Point: ${drillSalesPoints.length} selected`;
                    } else if (!drillTerritories.includes('ALL')) {
                      activeLevel = 'territory';
                      activeName = `Territory: ${drillTerritories.length} selected`;
                    } else if (!drillAreas.includes('ALL')) {
                      activeLevel = 'area';
                      activeName = `Area: ${drillAreas.length} selected`;
                    } else if (!drillRegions.includes('ALL')) {
                      activeLevel = 'region';
                      activeName = `Region: ${drillRegions.length} selected`;
                    } else {
                      activeLevel = 'national';
                      activeName = 'National Overview';
                    }

                    const visits = cascadingDrillData.finalVisits;

                    // KPI Summary
                    const totalVisits = visits.length;
                    const seenForDup = new Set<string>();
                    let totalDuplicates = 0;
                    const chronoVisits = getChronologicalVisits(visits);
                    chronoVisits.forEach(v => {
                      if (seenForDup.has(v.outletCode)) totalDuplicates++;
                      else seenForDup.add(v.outletCode);
                    });
                    const totalViolations = visits.filter(v => v.distance > 30).length;
                    const uniqueOutletsCount = new Set(visits.map(v => v.outletCode)).size;

                    // Group by Date for summary views
                    const dateGroups = new Map<string, VisitRecord[]>();
                    chronoVisits.forEach(v => {
                      if (!dateGroups.has(v.visitDate)) dateGroups.set(v.visitDate, []);
                      dateGroups.get(v.visitDate)!.push(v);
                    });
                    const dateRows = Array.from(dateGroups.entries())
                      .sort((a, b) => a[0].localeCompare(b[0]))
                      .map(([date, dayVisits]) => {
                        const dayUnique = new Set(dayVisits.map(v => v.outletCode)).size;
                        const dayViolations = dayVisits.filter(v => v.distance > 30).length;
                        const daySeen = new Set<string>();
                        let dayDups = 0;
                        dayVisits.forEach(v => {
                          if (daySeen.has(v.outletCode)) dayDups++;
                          else daySeen.add(v.outletCode);
                        });
                        return { date, visits: dayVisits.length, unique: dayUnique, violations: dayViolations, duplicates: dayDups };
                      });

                    return (
                      <>
                        <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
                          <div>
                            <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
                              <div className={`w-2 h-2 rounded-full ${
                                activeLevel === 'national' ? 'bg-purple-500' :
                                activeLevel === 'region' ? 'bg-blue-500' :
                                activeLevel === 'area' ? 'bg-cyan-500' :
                                activeLevel === 'territory' ? 'bg-emerald-500' :
                                activeLevel === 'salesPoint' ? 'bg-amber-500' :
                                activeLevel === 'route' ? 'bg-indigo-500' : 'bg-rose-500'
                              }`} />
                              {activeName}
                            </h3>
                            <p className="text-xs text-slate-500 mt-0.5">
                              {activeLevel === 'outlet' 
                                ? `Showing all visit records for this outlet within your selected date range`
                                : `Date-wise summary of ${visits.length} total visit records matching your filters`}
                            </p>
                          </div>
                          
                          <div className="flex items-center gap-3">
                            <div className="flex items-center gap-3 text-xs bg-slate-50 px-3 py-2 rounded-lg border border-slate-200">
                              <div><span className="font-semibold text-slate-700">Total:</span> {totalVisits}</div>
                              <div className="h-3 w-px bg-slate-300" />
                              <div><span className="font-semibold text-emerald-600">Outlets:</span> {uniqueOutletsCount}</div>
                              <div className="h-3 w-px bg-slate-300" />
                              <div><span className="font-semibold text-red-600">Violations:</span> {totalViolations}</div>
                              <div className="h-3 w-px bg-slate-300" />
                              <div><span className="font-semibold text-amber-600">Duplicates:</span> {totalDuplicates}</div>
                            </div>

                            <button
                              onClick={() => {
                                if (activeLevel === 'outlet') {
                                  const rows = visits.map(v => ({
                                    'Visit Date': v.visitDate,
                                    'Sales Point': v.salesPointName,
                                    'Route Name': v.routeName,
                                    'Outlet Code': v.outletCode,
                                    'Outlet Name': v.outletName,
                                    'Check-in Distance (m)': v.distance,
                                    'Status': v.distance > 30 ? 'Violation (>30m)' : 'OK',
                                    'Latitude': v.lat,
                                    'Longitude': v.long
                                  }));
                                  const ws = XLSX.utils.json_to_sheet(rows);
                                  const wb = XLSX.utils.book_new();
                                  XLSX.utils.book_append_sheet(wb, ws, "Outlet Visits");
                                  XLSX.writeFile(wb, `GeoTracker_Outlet_${drillOutlet}_${format(new Date(), 'yyyyMMdd')}.xlsx`);
                                } else {
                                  const rows = dateRows.map(r => ({
                                    'Date': r.date,
                                    'Total Visits': r.visits,
                                    'Unique Outlets': r.unique,
                                    'Geo Violations': r.violations,
                                    'Duplicate Visits': r.duplicates
                                  }));
                                  const ws = XLSX.utils.json_to_sheet(rows);
                                  const wb = XLSX.utils.book_new();
                                  XLSX.utils.book_append_sheet(wb, ws, `${activeLevel.charAt(0).toUpperCase() + activeLevel.slice(1)} Summary`);
                                  XLSX.writeFile(wb, `GeoTracker_${activeLevel}_${format(new Date(), 'yyyyMMdd')}.xlsx`);
                                }
                              }}
                              className="flex items-center gap-1.5 bg-indigo-50 hover:bg-indigo-600 hover:text-white text-indigo-700 px-3 py-1.5 rounded-md text-xs font-bold shadow-sm transition-all border border-indigo-100"
                            >
                              <FileSpreadsheet size={14} />
                              Export Excel
                            </button>
                          </div>
                        </div>

                        <div className="overflow-x-auto flex-1 max-h-[550px]">
                          {activeLevel === 'outlet' ? (
                            /* OUTLET DETAIL TABLE */
                            <table className="w-full text-left border-collapse">
                              <thead className="bg-slate-50 sticky top-0 z-10 shadow-sm">
                                <tr>
                                  <th className="px-3 py-2.5 text-xs font-semibold text-slate-500 uppercase">Date</th>
                                  <th className="px-3 py-2.5 text-xs font-semibold text-slate-500 uppercase">Sales Point</th>
                                  <th className="px-3 py-2.5 text-xs font-semibold text-slate-500 uppercase">Route</th>
                                  <th className="px-3 py-2.5 text-xs font-semibold text-slate-500 uppercase">Geo Distance</th>
                                  <th className="px-3 py-2.5 text-center text-xs font-semibold text-slate-500 uppercase">Status</th>
                                  <th className="px-3 py-2.5 text-center text-xs font-semibold text-slate-500 uppercase">Visit Type</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-slate-200 text-sm align-middle">
                                {(() => {
                                  const seenForTable = new Set<string>();
                                  return chronoVisits.map((v) => {
                                    const isViolation = v.distance > 30;
                                    const isDuplicateVisit = seenForTable.has(v.outletCode);
                                    if (!isDuplicateVisit) seenForTable.add(v.outletCode);
                                    
                                    return (
                                      <tr key={v.id} className="hover:bg-indigo-50/40 transition-colors">
                                        <td className="px-3 py-3 font-medium text-slate-900 whitespace-nowrap">{v.visitDate}</td>
                                        <td className="px-3 py-3 text-slate-700 whitespace-nowrap">{v.salesPointName}</td>
                                        <td className="px-3 py-3 text-slate-600 whitespace-nowrap">{v.routeName}</td>
                                        <td className="px-3 py-3 text-right whitespace-nowrap">
                                          <span className={`font-bold ${isViolation ? 'text-red-600' : 'text-slate-700'}`}>{v.distance}m</span>
                                        </td>
                                        <td className="px-3 py-3 text-center whitespace-nowrap">
                                          <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${isViolation ? 'bg-red-100 text-red-800' : 'bg-emerald-100 text-emerald-800'}`}>
                                            {isViolation ? 'Violation' : 'OK'}
                                          </span>
                                        </td>
                                        <td className="px-3 py-3 text-center whitespace-nowrap">
                                          <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-bold ${isDuplicateVisit ? 'bg-amber-100 text-amber-800 border border-amber-300' : 'bg-slate-100 text-slate-600'}`}>
                                            {isDuplicateVisit ? 'Duplicate Visit' : 'Unique Visit'}
                                          </span>
                                        </td>
                                      </tr>
                                    );
                                  });
                                })()}
                                {visits.length === 0 && (
                                  <tr><td colSpan={6} className="text-center py-12 text-slate-400">No visit records found.</td></tr>
                                )}
                              </tbody>
                            </table>
                          ) : (
                            /* DATE-WISE SUMMARY TABLE for National/Region/Area/Territory/Sales Point/Route */
                            <table className="w-full text-left border-collapse">
                              <thead className="bg-slate-50 sticky top-0 z-10 shadow-sm">
                                <tr>
                                  <th className="px-4 py-2.5 text-left text-xs font-semibold text-slate-500 uppercase">Date</th>
                                  <th className="px-4 py-2.5 text-right text-xs font-semibold text-slate-500 uppercase">Total Visits</th>
                                  <th className="px-4 py-2.5 text-right text-xs font-semibold text-slate-500 uppercase">Unique Outlets</th>
                                  <th className="px-4 py-2.5 text-right text-xs font-semibold text-slate-500 uppercase">Geo Violations</th>
                                  <th className="px-4 py-2.5 text-right text-xs font-semibold text-slate-500 uppercase">Duplicate Visits</th>
                                  <th className="px-4 py-2.5 text-center text-xs font-semibold text-slate-500 uppercase">Action</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-slate-200 text-sm">
                                {dateRows.map((row) => (
                                  <tr key={row.date} className="hover:bg-indigo-50/40 transition-colors">
                                    <td className="px-4 py-3 font-semibold text-slate-900 whitespace-nowrap">{row.date}</td>
                                    <td className="px-4 py-3 text-right font-medium text-slate-900">{row.visits}</td>
                                    <td className="px-4 py-3 text-right text-slate-700">{row.unique}</td>
                                    <td className="px-4 py-3 text-right">
                                      <span className={`font-medium ${row.violations > 0 ? 'text-red-600' : 'text-emerald-600'}`}>
                                        {row.violations}
                                      </span>
                                    </td>
                                    <td className="px-4 py-3 text-right">
                                      <span className={`font-medium ${row.duplicates > 0 ? 'text-amber-600' : 'text-emerald-600'}`}>
                                        {row.duplicates}
                                      </span>
                                    </td>
                                    <td className="px-4 py-3 text-center">
                                      <span className="text-xs text-indigo-600 cursor-pointer hover:underline">
                                        {row.visits} records
                                      </span>
                                    </td>
                                  </tr>
                                ))}
                                {dateRows.length === 0 && (
                                  <tr><td colSpan={6} className="text-center py-12 text-slate-400">No data available. Please upload visit data to see analytics.</td></tr>
                                )}
                                {dateRows.length > 0 && (
                                  <>
                                    <tr className="bg-slate-50 font-semibold">
                                      <td className="px-4 py-3 text-slate-900">TOTAL</td>
                                      <td className="px-4 py-3 text-right text-slate-900">{dateRows.reduce((s, r) => s + r.visits, 0)}</td>
                                      <td className="px-4 py-3 text-right text-slate-700">{uniqueOutletsCount}</td>
                                      <td className="px-4 py-3 text-right text-red-600">{dateRows.reduce((s, r) => s + r.violations, 0)}</td>
                                      <td className="px-4 py-3 text-right text-amber-600">{dateRows.reduce((s, r) => s + r.duplicates, 0)}</td>
                                      <td className="px-4 py-3 text-center">—</td>
                                    </tr>
                                  </>
                                )}
                              </tbody>
                            </table>
                          )}
                        </div>
                      </>
                    );
                  })()}
                </div>
              </div>
            </div>
          )}
          
          {activeTab === 'master' && (
            <div className="space-y-6">
              <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h3 className="text-lg font-semibold text-slate-900">Hierarchy Management</h3>
                    <p className="text-sm text-slate-500 mt-1">Manage your organizational structure: National → Region → Area → Territory → Sales Point</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setMasterEditMode(!masterEditMode)}
                      className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                        masterEditMode ? 'bg-indigo-100 text-indigo-700' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      <Edit2 size={16} />
                      {masterEditMode ? 'Done Editing' : 'Edit Mode'}
                    </button>
                    {newNodeForm ? (
                      <button
                        onClick={() => setNewNodeForm(null)}
                        className="flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-sm font-medium"
                      >
                        <X size={16} />
                        Cancel
                      </button>
                    ) : (
                      <button
                        onClick={() => setNewNodeForm({ name: '', type: 'salesPoint', parentId: '', salesPointCode: '' })}
                        className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-medium"
                      >
                        <Plus size={16} />
                        Add Node
                      </button>
                    )}
                  </div>
                </div>
                
                {/* Add Node Form */}
                {newNodeForm && (
                  <div className="bg-slate-50 rounded-xl p-4 mb-6">
                    <div className="grid grid-cols-5 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-slate-700 mb-2">Node Name</label>
                        <input
                          type="text"
                          className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm"
                          placeholder="Enter name"
                          value={newNodeForm.name}
                          onChange={(e) => setNewNodeForm({ ...newNodeForm, name: e.target.value })}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-slate-700 mb-2">Type</label>
                        <select
                          className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm"
                          value={newNodeForm.type}
                          onChange={(e) => setNewNodeForm({ ...newNodeForm, type: e.target.value as any, salesPointCode: e.target.value === 'salesPoint' ? newNodeForm.salesPointCode : '' })}
                        >
                          <option value="region">Region</option>
                          <option value="area">Area</option>
                          <option value="territory">Territory</option>
                          <option value="salesPoint">Sales Point</option>
                        </select>
                      </div>
                      {newNodeForm.type === 'salesPoint' && (
                        <div>
                          <label className="block text-sm font-medium text-slate-700 mb-2">Sales Point Code</label>
                          <input
                            type="text"
                            className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm uppercase"
                            placeholder="e.g. NOA-MAJ-01"
                            value={newNodeForm.salesPointCode}
                            onChange={(e) => setNewNodeForm({ ...newNodeForm, salesPointCode: e.target.value.toUpperCase() })}
                          />
                        </div>
                      )}
                      <div>
                        <label className="block text-sm font-medium text-slate-700 mb-2">Parent</label>
                        <select
                          className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm"
                          value={newNodeForm.parentId}
                          onChange={(e) => setNewNodeForm({ ...newNodeForm, parentId: e.target.value })}
                        >
                          <option value="">Select Parent</option>
                          {hierarchy
                            .filter(n => {
                              const typeOrder = ['national', 'region', 'area', 'territory', 'salesPoint'];
                              const newTypeIndex = typeOrder.indexOf(newNodeForm.type);
                              const parentTypeIndex = typeOrder.indexOf(n.type);
                              return parentTypeIndex === newTypeIndex - 1;
                            })
                            .map(n => (
                              <option key={n.id} value={n.id}>{n.name}</option>
                            ))}
                        </select>
                      </div>
                      <div className="flex items-end">
                        <button
                          onClick={addNode}
                          disabled={!newNodeForm.name || !newNodeForm.parentId}
                          className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white rounded-lg text-sm font-medium"
                        >
                          <Save size={16} />
                          Save Node
                        </button>
                      </div>
                    </div>
                  </div>
                )}
                
                {/* Hierarchy Tree View */}
                <div className="bg-slate-50 rounded-xl p-4">
                  <div className="space-y-1">
                    {hierarchy.filter(n => n.type === 'national').map(national => (
                      <div key={national.id}>
                        <div className="flex items-center gap-3 p-3 bg-white rounded-lg shadow-sm">
                          <Globe className="text-purple-600" size={20} />
                          <span className="font-semibold text-slate-900">{national.name}</span>
                          <span className="ml-auto text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded-full">National</span>
                        </div>
                        
                        <div className="ml-8 mt-2 space-y-2">
                          {hierarchy.filter(n => n.parentId === national.id).map(region => (
                            <div key={region.id}>
                              <div className="flex items-center gap-3 p-3 bg-white rounded-lg shadow-sm">
                                <Building2 className="text-blue-600" size={18} />
                                <span className="font-medium text-slate-900">{region.name}</span>
                                <span className="text-xs text-slate-500">
                                  {hierarchy.filter(n => n.parentId === region.id).length} areas
                                </span>
                                <span className="ml-auto text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Region</span>
                                {masterEditMode && (
                                  <button
                                    onClick={() => deleteNode(region.id)}
                                    className="p-1 text-red-500 hover:bg-red-50 rounded"
                                  >
                                    <Trash2 size={14} />
                                  </button>
                                )}
                              </div>
                              
                              <div className="ml-6 mt-2 space-y-2">
                                {hierarchy.filter(n => n.parentId === region.id).map(area => (
                                  <div key={area.id}>
                                    <div className="flex items-center gap-3 p-2 bg-white rounded-lg shadow-sm border border-slate-100">
                                      <Layers className="text-cyan-600" size={16} />
                                      <span className="font-medium text-slate-800">{area.name}</span>
                                      <span className="text-xs text-slate-500">
                                        {hierarchy.filter(n => n.parentId === area.id).length} territories
                                      </span>
                                      <span className="ml-auto text-xs bg-cyan-100 text-cyan-700 px-2 py-0.5 rounded-full">Area</span>
                                      {masterEditMode && (
                                        <button
                                          onClick={() => deleteNode(area.id)}
                                          className="p-1 text-red-500 hover:bg-red-50 rounded"
                                        >
                                          <Trash2 size={14} />
                                        </button>
                                      )}
                                    </div>
                                    
                                    <div className="ml-6 mt-1 space-y-1">
                                      {hierarchy.filter(n => n.parentId === area.id).map(territory => (
                                        <div key={territory.id}>
                                          <div className="flex items-center gap-3 p-2 bg-white rounded-lg shadow-sm border border-slate-100">
                                            <MapIcon className="text-emerald-600" size={16} />
                                            <span className="font-medium text-slate-700">{territory.name}</span>
                                            <span className="text-xs text-slate-500">
                                              {hierarchy.filter(n => n.parentId === territory.id).length} sales points
                                            </span>
                                            <span className="ml-auto text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full">Territory</span>
                                            {masterEditMode && (
                                              <button
                                                onClick={() => deleteNode(territory.id)}
                                                className="p-1 text-red-500 hover:bg-red-50 rounded"
                                              >
                                                <Trash2 size={14} />
                                              </button>
                                            )}
                                          </div>
                                          
                                          <div className="ml-6 mt-1 space-y-1">
                                            {hierarchy.filter(n => n.parentId === territory.id).map(sp => (
                                              <div key={sp.id} className="flex items-center gap-3 p-2 bg-white rounded-lg shadow-sm border border-slate-100">
                                                <Store className="text-amber-600" size={14} />
                                                <div>
                                                  <span className="text-sm text-slate-700 block">{sp.name}</span>
                                                  <span className="text-[11px] text-slate-400 font-mono">{sp.salesPointCode || 'N/A'}</span>
                                                </div>
                                                <span className="ml-auto text-xs bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full">Sales Point</span>
                                                {masterEditMode && (
                                                  <button
                                                    onClick={() => deleteNode(sp.id)}
                                                    className="p-1 text-red-500 hover:bg-red-50 rounded"
                                                  >
                                                    <Trash2 size={14} />
                                                  </button>
                                                )}
                                              </div>
                                            ))}
                                          </div>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              
              {/* Stats Summary */}
              <div className="grid grid-cols-5 gap-4">
                {[
                  { label: 'National', count: hierarchy.filter(n => n.type === 'national').length, icon: Globe, color: 'purple' },
                  { label: 'Regions', count: hierarchy.filter(n => n.type === 'region').length, icon: Building2, color: 'blue' },
                  { label: 'Areas', count: hierarchy.filter(n => n.type === 'area').length, icon: Layers, color: 'cyan' },
                  { label: 'Territories', count: hierarchy.filter(n => n.type === 'territory').length, icon: MapIcon, color: 'emerald' },
                  { label: 'Sales Points', count: hierarchy.filter(n => n.type === 'salesPoint').length, icon: Store, color: 'amber' },
                ].map(stat => (
                  <div key={stat.label} className="bg-white rounded-xl p-4 shadow-sm border border-slate-200 flex items-center gap-3">
                    <div className={`p-3 bg-${stat.color}-50 rounded-lg`}>
                      <stat.icon className={`text-${stat.color}-600`} size={20} />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-slate-900">{stat.count}</p>
                      <p className="text-xs text-slate-500">{stat.label}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {activeTab === 'security' && isAdmin && (
            <SecurityPanel currentUser={currentUser} />
          )}
        </div>
      </main>
    </div>
  );
}
