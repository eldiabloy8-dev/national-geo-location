import React, { useState, useEffect } from 'react';
import { 
  Lock, User, Eye, EyeOff, Shield, MapPin, LogIn, AlertCircle,
  Plus, Trash2, X, Save, UserCog, Crown, UserCheck, Users
} from 'lucide-react';

export interface AuthUser {
  username: string;
  password: string; // simple base64 encoded for demo (NOT secure for production!)
  role: 'admin' | 'user';
  fullName: string;
  createdAt: string;
}

export interface LoggedInUser {
  username: string;
  role: 'admin' | 'user';
  fullName: string;
}

const STORAGE_USERS_KEY = 'geoTracker_users';
const STORAGE_SESSION_KEY = 'geoTracker_session';

// Simple obfuscation (NOT proper encryption - for demo only)
const encode = (str: string) => btoa(str);
const decode = (str: string) => {
  try { return atob(str); } catch { return ''; }
};

// Default admin user setup
export const initializeAuth = (): AuthUser[] => {
  const saved = localStorage.getItem(STORAGE_USERS_KEY);
  if (saved) {
    try { return JSON.parse(saved); } catch { /* fallthrough */ }
  }
  
  // Create default admin
  const defaultUsers: AuthUser[] = [
    {
      username: 'admin',
      password: encode('admin123'),
      role: 'admin',
      fullName: 'System Administrator',
      createdAt: new Date().toISOString()
    }
  ];
  localStorage.setItem(STORAGE_USERS_KEY, JSON.stringify(defaultUsers));
  return defaultUsers;
};

export const getCurrentSession = (): LoggedInUser | null => {
  const session = localStorage.getItem(STORAGE_SESSION_KEY);
  if (!session) return null;
  try { return JSON.parse(session); } catch { return null; }
};

export const logout = () => {
  localStorage.removeItem(STORAGE_SESSION_KEY);
  window.location.reload();
};

// Login Page Component
interface LoginPageProps {
  onLogin: (user: LoggedInUser) => void;
}

export function LoginPage({ onLogin }: LoginPageProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    initializeAuth();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    setTimeout(() => {
      const users = initializeAuth();
      const user = users.find(u => u.username.toLowerCase() === username.toLowerCase());
      
      if (!user) {
        setError('User not found. Please check your username.');
        setLoading(false);
        return;
      }
      
      if (decode(user.password) !== password) {
        setError('Incorrect password. Please try again.');
        setLoading(false);
        return;
      }

      const session: LoggedInUser = {
        username: user.username,
        role: user.role,
        fullName: user.fullName
      };
      
      localStorage.setItem(STORAGE_SESSION_KEY, JSON.stringify(session));
      onLogin(session);
    }, 400);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 p-6 relative overflow-hidden">
      {/* Decorative background */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-20 w-72 h-72 bg-indigo-500 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-20 w-72 h-72 bg-purple-500 rounded-full blur-3xl" />
      </div>

      <div className="relative w-full max-w-md">
        {/* Branding Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 shadow-2xl mb-4">
            <MapPin className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">GeoTracker Pro</h1>
          <p className="text-slate-400 text-sm">National Sales Point Analytics System</p>
        </div>

        {/* Login Card */}
        <div className="bg-white rounded-2xl shadow-2xl p-8 border border-white/10">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-indigo-100 rounded-lg">
              <Shield className="w-5 h-5 text-indigo-600" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-900">Secure Login</h2>
              <p className="text-xs text-slate-500">Authorized access only</p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Username */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Username</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-sm"
                  placeholder="Enter your username"
                  required
                  autoFocus
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-10 py-2.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-sm"
                  placeholder="Enter your password"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Error message */}
            {error && (
              <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0" />
                <p className="text-sm text-red-700">{error}</p>
              </div>
            )}

            {/* Login button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold py-2.5 rounded-lg shadow-md transition-all"
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Authenticating...
                </>
              ) : (
                <>
                  <LogIn className="w-4 h-4" />
                  Sign In
                </>
              )}
            </button>
          </form>

          {/* Default credentials hint */}
          <div className="mt-6 pt-4 border-t border-slate-200">
            <div className="flex items-start gap-2 p-3 bg-amber-50 border border-amber-200 rounded-lg">
              <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
              <div className="text-xs text-amber-800">
                <p className="font-semibold mb-1">Default Admin Credentials:</p>
                <p>Username: <span className="font-mono bg-white px-1.5 py-0.5 rounded">admin</span></p>
                <p>Password: <span className="font-mono bg-white px-1.5 py-0.5 rounded">admin123</span></p>
                <p className="mt-1 text-amber-700 italic">Please change the default password after first login!</p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <p className="text-center text-slate-500 text-xs mt-6">
          © 2026 GeoTracker Pro · Secure Geo-Location Analytics
        </p>
      </div>
    </div>
  );
}

// Security Panel - User Management Component (Admin only)
interface SecurityPanelProps {
  currentUser: LoggedInUser;
}

export function SecurityPanel({ currentUser }: SecurityPanelProps) {
  const [users, setUsers] = useState<AuthUser[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newUser, setNewUser] = useState({
    username: '',
    password: '',
    fullName: '',
    role: 'user' as 'admin' | 'user'
  });
  const [editingPassword, setEditingPassword] = useState<string | null>(null);
  const [newPasswordValue, setNewPasswordValue] = useState('');

  useEffect(() => {
    setUsers(initializeAuth());
  }, []);

  const saveUsers = (updated: AuthUser[]) => {
    localStorage.setItem(STORAGE_USERS_KEY, JSON.stringify(updated));
    setUsers(updated);
  };

  const handleAddUser = () => {
    if (!newUser.username.trim() || !newUser.password.trim() || !newUser.fullName.trim()) {
      alert('Please fill in all fields.');
      return;
    }
    
    if (newUser.password.length < 4) {
      alert('Password must be at least 4 characters long.');
      return;
    }
    
    if (users.some(u => u.username.toLowerCase() === newUser.username.toLowerCase())) {
      alert('Username already exists. Please choose a different username.');
      return;
    }

    const userToAdd: AuthUser = {
      username: newUser.username.trim(),
      password: encode(newUser.password),
      role: newUser.role,
      fullName: newUser.fullName.trim(),
      createdAt: new Date().toISOString()
    };

    saveUsers([...users, userToAdd]);
    setNewUser({ username: '', password: '', fullName: '', role: 'user' });
    setShowAddForm(false);
    alert(`✓ User "${userToAdd.username}" created successfully!`);
  };

  const handleDeleteUser = (username: string) => {
    if (username === currentUser.username) {
      alert('You cannot delete your own account.');
      return;
    }
    if (username === 'admin') {
      alert('Cannot delete the default admin account.');
      return;
    }
    if (!confirm(`Delete user "${username}"? This cannot be undone.`)) return;
    
    saveUsers(users.filter(u => u.username !== username));
  };

  const handleChangePassword = (username: string) => {
    if (newPasswordValue.length < 4) {
      alert('Password must be at least 4 characters.');
      return;
    }
    saveUsers(users.map(u => 
      u.username === username 
        ? { ...u, password: encode(newPasswordValue) }
        : u
    ));
    setEditingPassword(null);
    setNewPasswordValue('');
    alert(`✓ Password updated for "${username}"`);
  };

  const handleToggleRole = (username: string) => {
    if (username === currentUser.username) {
      alert('You cannot change your own role.');
      return;
    }
    if (username === 'admin') {
      alert('Cannot change the default admin role.');
      return;
    }
    saveUsers(users.map(u => 
      u.username === username 
        ? { ...u, role: u.role === 'admin' ? 'user' : 'admin' }
        : u
    ));
  };

  return (
    <div className="space-y-6">
      {/* Header Card */}
      <div className="bg-gradient-to-br from-indigo-600 to-purple-700 rounded-xl p-6 text-white shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-white/20 backdrop-blur rounded-xl">
              <Shield className="w-8 h-8" />
            </div>
            <div>
              <h2 className="text-2xl font-bold">Security Panel</h2>
              <p className="text-indigo-100 text-sm mt-1">Manage system users and access permissions</p>
            </div>
          </div>
          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="flex items-center gap-2 bg-white text-indigo-700 hover:bg-indigo-50 px-4 py-2 rounded-lg font-semibold shadow-md transition-all"
          >
            <Plus className="w-4 h-4" />
            Add New User
          </button>
        </div>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white rounded-xl p-4 shadow-sm border border-slate-200 flex items-center gap-3">
          <div className="p-3 bg-indigo-50 rounded-lg">
            <Users className="text-indigo-600 w-5 h-5" />
          </div>
          <div>
            <p className="text-2xl font-bold text-slate-900">{users.length}</p>
            <p className="text-xs text-slate-500">Total Users</p>
          </div>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-sm border border-slate-200 flex items-center gap-3">
          <div className="p-3 bg-purple-50 rounded-lg">
            <Crown className="text-purple-600 w-5 h-5" />
          </div>
          <div>
            <p className="text-2xl font-bold text-slate-900">{users.filter(u => u.role === 'admin').length}</p>
            <p className="text-xs text-slate-500">Administrators</p>
          </div>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-sm border border-slate-200 flex items-center gap-3">
          <div className="p-3 bg-emerald-50 rounded-lg">
            <UserCheck className="text-emerald-600 w-5 h-5" />
          </div>
          <div>
            <p className="text-2xl font-bold text-slate-900">{users.filter(u => u.role === 'user').length}</p>
            <p className="text-xs text-slate-500">Regular Users</p>
          </div>
        </div>
      </div>

      {/* Add User Form */}
      {showAddForm && (
        <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
              <Plus className="w-5 h-5 text-indigo-600" />
              Create New User
            </h3>
            <button onClick={() => setShowAddForm(false)} className="text-slate-400 hover:text-slate-600">
              <X className="w-5 h-5" />
            </button>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Full Name *</label>
              <input
                type="text"
                value={newUser.fullName}
                onChange={(e) => setNewUser({ ...newUser, fullName: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                placeholder="John Doe"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Username *</label>
              <input
                type="text"
                value={newUser.username}
                onChange={(e) => setNewUser({ ...newUser, username: e.target.value.toLowerCase() })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                placeholder="johndoe"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Password *</label>
              <input
                type="text"
                value={newUser.password}
                onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-mono"
                placeholder="Min 4 characters"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Role *</label>
              <select
                value={newUser.role}
                onChange={(e) => setNewUser({ ...newUser, role: e.target.value as 'admin' | 'user' })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
              >
                <option value="user">Regular User (View Only)</option>
                <option value="admin">Administrator (Full Access)</option>
              </select>
            </div>
          </div>
          
          <div className="flex justify-end gap-3 mt-5 pt-4 border-t border-slate-100">
            <button
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 text-slate-600 hover:bg-slate-50 rounded-lg text-sm font-medium"
            >
              Cancel
            </button>
            <button
              onClick={handleAddUser}
              className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-semibold"
            >
              <Save className="w-4 h-4" />
              Create User
            </button>
          </div>
        </div>
      )}

      {/* Users List */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-semibold text-slate-900 flex items-center gap-2">
            <UserCog className="w-5 h-5 text-slate-600" />
            All System Users ({users.length})
          </h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">User</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Role</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Created</th>
                <th className="px-6 py-3 text-center text-xs font-semibold text-slate-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {users.map(user => (
                <React.Fragment key={user.username}>
                  <tr className="hover:bg-slate-50">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-white ${
                          user.role === 'admin' 
                            ? 'bg-gradient-to-br from-purple-500 to-indigo-600' 
                            : 'bg-gradient-to-br from-emerald-500 to-teal-600'
                        }`}>
                          {user.fullName.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <p className="font-semibold text-slate-900 flex items-center gap-2">
                            {user.fullName}
                            {user.username === currentUser.username && (
                              <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">You</span>
                            )}
                          </p>
                          <p className="text-xs text-slate-500 font-mono">@{user.username}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <button
                        onClick={() => handleToggleRole(user.username)}
                        disabled={user.username === currentUser.username || user.username === 'admin'}
                        className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold transition-colors ${
                          user.role === 'admin'
                            ? 'bg-purple-100 text-purple-700 hover:bg-purple-200'
                            : 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200'
                        } disabled:opacity-60 disabled:cursor-not-allowed`}
                        title={user.username === currentUser.username || user.username === 'admin' ? 'Cannot change this role' : 'Click to toggle role'}
                      >
                        {user.role === 'admin' ? <Crown className="w-3 h-3" /> : <UserCheck className="w-3 h-3" />}
                        {user.role === 'admin' ? 'Administrator' : 'User'}
                      </button>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-500">
                      {new Date(user.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          onClick={() => {
                            setEditingPassword(user.username);
                            setNewPasswordValue('');
                          }}
                          className="text-xs px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-md font-semibold transition-colors flex items-center gap-1"
                        >
                          <Lock className="w-3 h-3" />
                          Reset Password
                        </button>
                        <button
                          onClick={() => handleDeleteUser(user.username)}
                          disabled={user.username === currentUser.username || user.username === 'admin'}
                          className="text-xs px-3 py-1.5 bg-red-50 hover:bg-red-100 text-red-700 rounded-md font-semibold transition-colors flex items-center gap-1 disabled:opacity-40 disabled:cursor-not-allowed"
                        >
                          <Trash2 className="w-3 h-3" />
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                  {editingPassword === user.username && (
                    <tr className="bg-indigo-50">
                      <td colSpan={4} className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <Lock className="w-4 h-4 text-indigo-600" />
                          <input
                            type="text"
                            value={newPasswordValue}
                            onChange={(e) => setNewPasswordValue(e.target.value)}
                            placeholder="Enter new password (min 4 chars)"
                            className="flex-1 px-3 py-2 border border-indigo-300 rounded-lg text-sm font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
                            autoFocus
                          />
                          <button
                            onClick={() => handleChangePassword(user.username)}
                            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-semibold flex items-center gap-1"
                          >
                            <Save className="w-3 h-3" />
                            Save
                          </button>
                          <button
                            onClick={() => { setEditingPassword(null); setNewPasswordValue(''); }}
                            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-sm font-semibold"
                          >
                            Cancel
                          </button>
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Security Notice */}
      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
        <div className="text-sm text-amber-800">
          <p className="font-semibold mb-1">Security Information</p>
          <ul className="space-y-1 list-disc list-inside text-amber-700">
            <li>User credentials are stored locally in this browser only</li>
            <li>Administrators have full access to all features including user management</li>
            <li>Regular users can view dashboards and analytics but cannot manage users or master data</li>
            <li>The default <span className="font-mono bg-white px-1 rounded">admin</span> account cannot be deleted or demoted</li>
          </ul>
        </div>
      </div>
    </div>
  );
}


